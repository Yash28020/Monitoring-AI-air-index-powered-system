import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Settings as SettingsIcon, 
  User, 
  Bell, 
  Shield, 
  Database, 
  Palette, 
  Globe, 
  Save,
  RefreshCw,
  Download,
  Upload,
  Trash2,
  Eye,
  EyeOff
} from 'lucide-react';
import { useAuth } from '../auth/AuthProvider';
import toast from 'react-hot-toast';

export const Settings: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [isLoading, setIsLoading] = useState(false);
  
  // Profile settings
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    organization: user?.organization || '',
    role: user?.role || 'researcher',
    phone: '+91 9876543210',
    location: 'New Delhi, India',
    bio: 'Environmental scientist specializing in air quality monitoring and satellite remote sensing.'
  });

  // Notification settings
  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    pushNotifications: true,
    weeklyReports: true,
    criticalAlerts: true,
    dataUpdates: false,
    systemMaintenance: true
  });

  // API settings
  const [apiSettings, setApiSettings] = useState({
    refreshInterval: 30,
    dataRetention: 90,
    maxRequests: 1000,
    enableCaching: true,
    compressionLevel: 'medium'
  });

  // Theme settings
  const [themeSettings, setThemeSettings] = useState({
    theme: 'dark',
    accentColor: 'blue',
    fontSize: 'medium',
    animations: true,
    highContrast: false
  });

  const handleSave = async (section: string) => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success(`${section} settings saved successfully!`);
    } catch (error) {
      toast.error('Failed to save settings');
    } finally {
      setIsLoading(false);
    }
  };

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'api', label: 'API & Data', icon: Database },
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'system', label: 'System', icon: Globe }
  ];

  const renderProfileSettings = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-white/90 mb-2">Full Name</label>
          <input
            type="text"
            value={profileData.name}
            onChange={(e) => setProfileData({...profileData, name: e.target.value})}
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-white/90 mb-2">Email</label>
          <input
            type="email"
            value={profileData.email}
            onChange={(e) => setProfileData({...profileData, email: e.target.value})}
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-white/90 mb-2">Organization</label>
          <input
            type="text"
            value={profileData.organization}
            onChange={(e) => setProfileData({...profileData, organization: e.target.value})}
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-white/90 mb-2">Role</label>
          <select
            value={profileData.role}
            onChange={(e) => setProfileData({...profileData, role: e.target.value})}
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="researcher" className="text-gray-900">Researcher</option>
            <option value="scientist" className="text-gray-900">Scientist</option>
            <option value="analyst" className="text-gray-900">Data Analyst</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-white/90 mb-2">Phone</label>
          <input
            type="tel"
            value={profileData.phone}
            onChange={(e) => setProfileData({...profileData, phone: e.target.value})}
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-white/90 mb-2">Location</label>
          <input
            type="text"
            value={profileData.location}
            onChange={(e) => setProfileData({...profileData, location: e.target.value})}
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>
      <div>
        <label className="block text-sm font-medium text-white/90 mb-2">Bio</label>
        <textarea
          value={profileData.bio}
          onChange={(e) => setProfileData({...profileData, bio: e.target.value})}
          rows={4}
          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>
      <button
        onClick={() => handleSave('Profile')}
        disabled={isLoading}
        className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 px-6 py-3 rounded-lg text-white transition-colors"
      >
        {isLoading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
        <span>Save Changes</span>
      </button>
    </div>
  );

  const renderNotificationSettings = () => (
    <div className="space-y-6">
      <div className="space-y-4">
        {Object.entries(notifications).map(([key, value]) => (
          <div key={key} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
            <div>
              <h4 className="text-white font-medium capitalize">
                {key.replace(/([A-Z])/g, ' $1').trim()}
              </h4>
              <p className="text-white/70 text-sm">
                {key === 'emailAlerts' && 'Receive email notifications for important updates'}
                {key === 'pushNotifications' && 'Get push notifications in your browser'}
                {key === 'weeklyReports' && 'Weekly summary reports via email'}
                {key === 'criticalAlerts' && 'Immediate alerts for critical air quality levels'}
                {key === 'dataUpdates' && 'Notifications when new data is available'}
                {key === 'systemMaintenance' && 'System maintenance and update notifications'}
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={value}
                onChange={(e) => setNotifications({...notifications, [key]: e.target.checked})}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-white/20 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        ))}
      </div>
      <button
        onClick={() => handleSave('Notification')}
        disabled={isLoading}
        className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 px-6 py-3 rounded-lg text-white transition-colors"
      >
        {isLoading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
        <span>Save Preferences</span>
      </button>
    </div>
  );

  const renderSecuritySettings = () => (
    <div className="space-y-6">
      <div className="bg-white/5 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Password & Authentication</h3>
        <div className="space-y-4">
          <button className="w-full text-left p-4 bg-white/10 hover:bg-white/20 rounded-lg transition-colors">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-white font-medium">Change Password</h4>
                <p className="text-white/70 text-sm">Update your account password</p>
              </div>
              <Shield className="h-5 w-5 text-white/70" />
            </div>
          </button>
          <button className="w-full text-left p-4 bg-white/10 hover:bg-white/20 rounded-lg transition-colors">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-white font-medium">Two-Factor Authentication</h4>
                <p className="text-white/70 text-sm">Add an extra layer of security</p>
              </div>
              <div className="text-green-400 text-sm">Enabled</div>
            </div>
          </button>
        </div>
      </div>
      
      <div className="bg-white/5 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Active Sessions</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-white/10 rounded-lg">
            <div>
              <p className="text-white font-medium">Current Session</p>
              <p className="text-white/70 text-sm">Chrome on Windows • New Delhi, India</p>
            </div>
            <span className="text-green-400 text-sm">Active</span>
          </div>
          <div className="flex items-center justify-between p-3 bg-white/10 rounded-lg">
            <div>
              <p className="text-white font-medium">Mobile App</p>
              <p className="text-white/70 text-sm">iOS App • Last seen 2 hours ago</p>
            </div>
            <button className="text-red-400 text-sm hover:text-red-300">Revoke</button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderAPISettings = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-white/90 mb-2">Data Refresh Interval (seconds)</label>
          <input
            type="number"
            value={apiSettings.refreshInterval}
            onChange={(e) => setApiSettings({...apiSettings, refreshInterval: parseInt(e.target.value)})}
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-white/90 mb-2">Data Retention (days)</label>
          <input
            type="number"
            value={apiSettings.dataRetention}
            onChange={(e) => setApiSettings({...apiSettings, dataRetention: parseInt(e.target.value)})}
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-white/90 mb-2">Max API Requests/hour</label>
          <input
            type="number"
            value={apiSettings.maxRequests}
            onChange={(e) => setApiSettings({...apiSettings, maxRequests: parseInt(e.target.value)})}
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-white/90 mb-2">Compression Level</label>
          <select
            value={apiSettings.compressionLevel}
            onChange={(e) => setApiSettings({...apiSettings, compressionLevel: e.target.value})}
            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="low" className="text-gray-900">Low</option>
            <option value="medium" className="text-gray-900">Medium</option>
            <option value="high" className="text-gray-900">High</option>
          </select>
        </div>
      </div>
      
      <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
        <div>
          <h4 className="text-white font-medium">Enable Data Caching</h4>
          <p className="text-white/70 text-sm">Cache frequently accessed data for better performance</p>
        </div>
        <label className="relative inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            checked={apiSettings.enableCaching}
            onChange={(e) => setApiSettings({...apiSettings, enableCaching: e.target.checked})}
            className="sr-only peer"
          />
          <div className="w-11 h-6 bg-white/20 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
        </label>
      </div>

      <div className="flex space-x-4">
        <button className="flex items-center space-x-2 bg-green-500 hover:bg-green-600 px-4 py-2 rounded-lg text-white transition-colors">
          <Download className="h-4 w-4" />
          <span>Export Data</span>
        </button>
        <button className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-lg text-white transition-colors">
          <Upload className="h-4 w-4" />
          <span>Import Data</span>
        </button>
        <button className="flex items-center space-x-2 bg-red-500 hover:bg-red-600 px-4 py-2 rounded-lg text-white transition-colors">
          <Trash2 className="h-4 w-4" />
          <span>Clear Cache</span>
        </button>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'profile': return renderProfileSettings();
      case 'notifications': return renderNotificationSettings();
      case 'security': return renderSecuritySettings();
      case 'api': return renderAPISettings();
      case 'appearance': return (
        <div className="text-center py-12">
          <Palette className="h-12 w-12 text-white/50 mx-auto mb-4" />
          <p className="text-white/70">Appearance settings coming in next update</p>
        </div>
      );
      case 'system': return (
        <div className="text-center py-12">
          <Globe className="h-12 w-12 text-white/50 mx-auto mb-4" />
          <p className="text-white/70">System settings coming in next update</p>
        </div>
      );
      default: return renderProfileSettings();
    }
  };

  return (
    <div className="p-6 space-y-6">
      <h2 className="text-2xl font-bold text-white">Settings</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Settings Navigation */}
        <div className="lg:col-span-1">
          <nav className="space-y-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                  activeTab === tab.id
                    ? 'bg-blue-500 text-white'
                    : 'text-white/70 hover:text-white hover:bg-white/10'
                }`}
              >
                <tab.icon className="h-5 w-5" />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Settings Content */}
        <div className="lg:col-span-3">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
          >
            {renderContent()}
          </motion.div>
        </div>
      </div>
    </div>
  );
};