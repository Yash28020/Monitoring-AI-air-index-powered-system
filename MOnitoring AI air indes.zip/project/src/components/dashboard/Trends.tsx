import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Download, 
  Filter,
  BarChart3,
  LineChart as LineChartIcon,
  PieChart as PieChartIcon,
  Activity,
  MapPin,
  Satellite
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  ComposedChart
} from 'recharts';

const monthlyTrends = [
  { month: 'Jan', pm25: 145, pm10: 210, aod: 0.62, temperature: 18, humidity: 65 },
  { month: 'Feb', pm25: 132, pm10: 195, aod: 0.58, temperature: 22, humidity: 60 },
  { month: 'Mar', pm25: 98, pm10: 145, aod: 0.45, temperature: 28, humidity: 55 },
  { month: 'Apr', pm25: 76, pm10: 112, aod: 0.38, temperature: 32, humidity: 50 },
  { month: 'May', pm25: 89, pm10: 134, aod: 0.42, temperature: 35, humidity: 45 },
  { month: 'Jun', pm25: 67, pm10: 98, aod: 0.35, temperature: 33, humidity: 70 },
  { month: 'Jul', pm25: 54, pm10: 82, aod: 0.28, temperature: 30, humidity: 85 },
  { month: 'Aug', pm25: 61, pm10: 89, aod: 0.32, temperature: 29, humidity: 82 },
  { month: 'Sep', pm25: 78, pm10: 115, aod: 0.41, temperature: 31, humidity: 75 },
  { month: 'Oct', pm25: 112, pm10: 167, aod: 0.52, temperature: 28, humidity: 68 },
  { month: 'Nov', pm25: 156, pm10: 234, aod: 0.68, temperature: 23, humidity: 72 },
  { month: 'Dec', pm25: 178, pm10: 267, aod: 0.75, temperature: 19, humidity: 70 }
];

const hourlyTrends = [
  { hour: '00:00', pm25: 89, pm10: 134, traffic: 20 },
  { hour: '02:00', pm25: 76, pm10: 112, traffic: 15 },
  { hour: '04:00', pm25: 67, pm10: 98, traffic: 10 },
  { hour: '06:00', pm25: 98, pm10: 145, traffic: 60 },
  { hour: '08:00', pm25: 134, pm10: 189, traffic: 90 },
  { hour: '10:00', pm25: 156, pm10: 234, traffic: 85 },
  { hour: '12:00', pm25: 178, pm10: 267, traffic: 80 },
  { hour: '14:00', pm25: 165, pm10: 245, traffic: 75 },
  { hour: '16:00', pm25: 189, pm10: 278, traffic: 85 },
  { hour: '18:00', pm25: 212, pm10: 312, traffic: 95 },
  { hour: '20:00', pm25: 198, pm10: 289, traffic: 70 },
  { hour: '22:00', pm25: 145, pm10: 210, traffic: 45 }
];

const seasonalData = [
  { season: 'Winter', pm25: 167, pm10: 245, aod: 0.68, color: '#3B82F6' },
  { season: 'Spring', pm25: 87, pm10: 128, aod: 0.41, color: '#10B981' },
  { season: 'Summer', pm25: 77, pm10: 115, aod: 0.38, color: '#F59E0B' },
  { season: 'Monsoon', pm25: 61, pm10: 89, aod: 0.32, color: '#8B5CF6' }
];

const cityComparison = [
  { city: 'Delhi', pm25_2023: 156, pm25_2024: 142, improvement: -9 },
  { city: 'Mumbai', pm25_2023: 89, pm25_2024: 94, improvement: 6 },
  { city: 'Bangalore', pm25_2023: 67, pm25_2024: 61, improvement: -9 },
  { city: 'Chennai', pm25_2023: 78, pm25_2024: 73, improvement: -6 },
  { city: 'Kolkata', pm25_2023: 134, pm25_2024: 128, improvement: -4 },
  { city: 'Hyderabad', pm25_2023: 72, pm25_2024: 68, improvement: -6 }
];

export const Trends: React.FC = () => {
  const [selectedTimeRange, setSelectedTimeRange] = useState('monthly');
  const [selectedMetric, setSelectedMetric] = useState('pm25');
  const [selectedCity, setSelectedCity] = useState('all');
  const [chartType, setChartType] = useState('line');

  const getChartData = () => {
    switch (selectedTimeRange) {
      case 'hourly': return hourlyTrends;
      case 'monthly': return monthlyTrends;
      default: return monthlyTrends;
    }
  };

  const renderChart = () => {
    const data = getChartData();
    
    if (chartType === 'area') {
      return (
        <ResponsiveContainer width="100%" height={400}>
          <AreaChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
            <XAxis dataKey={selectedTimeRange === 'hourly' ? 'hour' : 'month'} stroke="#ffffff70" />
            <YAxis stroke="#ffffff70" />
            <Tooltip 
              contentStyle={{
                backgroundColor: '#1f2937',
                border: '1px solid #374151',
                borderRadius: '8px',
                color: '#ffffff'
              }}
            />
            <Legend />
            <Area 
              type="monotone" 
              dataKey={selectedMetric} 
              stroke="#3B82F6" 
              fill="#3B82F6" 
              fillOpacity={0.3}
              name={selectedMetric.toUpperCase()}
            />
          </AreaChart>
        </ResponsiveContainer>
      );
    }

    if (chartType === 'bar') {
      return (
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
            <XAxis dataKey={selectedTimeRange === 'hourly' ? 'hour' : 'month'} stroke="#ffffff70" />
            <YAxis stroke="#ffffff70" />
            <Tooltip 
              contentStyle={{
                backgroundColor: '#1f2937',
                border: '1px solid #374151',
                borderRadius: '8px',
                color: '#ffffff'
              }}
            />
            <Legend />
            <Bar dataKey={selectedMetric} fill="#3B82F6" name={selectedMetric.toUpperCase()} />
          </BarChart>
        </ResponsiveContainer>
      );
    }

    return (
      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
          <XAxis dataKey={selectedTimeRange === 'hourly' ? 'hour' : 'month'} stroke="#ffffff70" />
          <YAxis stroke="#ffffff70" />
          <Tooltip 
            contentStyle={{
              backgroundColor: '#1f2937',
              border: '1px solid #374151',
              borderRadius: '8px',
              color: '#ffffff'
            }}
          />
          <Legend />
          <Line 
            type="monotone" 
            dataKey={selectedMetric} 
            stroke="#3B82F6" 
            strokeWidth={3}
            name={selectedMetric.toUpperCase()}
          />
        </LineChart>
      </ResponsiveContainer>
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Trend Analysis</h2>
        <div className="flex items-center space-x-4">
          <select 
            value={selectedTimeRange}
            onChange={(e) => setSelectedTimeRange(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white text-sm"
          >
            <option value="hourly" className="text-gray-900">Hourly</option>
            <option value="monthly" className="text-gray-900">Monthly</option>
          </select>
          <select 
            value={selectedMetric}
            onChange={(e) => setSelectedMetric(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white text-sm"
          >
            <option value="pm25" className="text-gray-900">PM2.5</option>
            <option value="pm10" className="text-gray-900">PM10</option>
            <option value="aod" className="text-gray-900">AOD</option>
          </select>
          <select 
            value={chartType}
            onChange={(e) => setChartType(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white text-sm"
          >
            <option value="line" className="text-gray-900">Line Chart</option>
            <option value="area" className="text-gray-900">Area Chart</option>
            <option value="bar" className="text-gray-900">Bar Chart</option>
          </select>
          <button className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-lg text-white transition-colors">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/70 text-sm">Annual Average PM2.5</p>
              <p className="text-2xl font-bold text-white">87.3 μg/m³</p>
              <div className="flex items-center mt-2">
                <TrendingDown className="h-4 w-4 text-green-400 mr-1" />
                <span className="text-green-400 text-sm">-12% from last year</span>
              </div>
            </div>
            <Activity className="h-8 w-8 text-blue-400" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/70 text-sm">Peak Season Impact</p>
              <p className="text-2xl font-bold text-white">+92%</p>
              <div className="flex items-center mt-2">
                <TrendingUp className="h-4 w-4 text-orange-400 mr-1" />
                <span className="text-orange-400 text-sm">Winter vs Summer</span>
              </div>
            </div>
            <Calendar className="h-8 w-8 text-orange-400" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/70 text-sm">Best Performing City</p>
              <p className="text-2xl font-bold text-white">Bangalore</p>
              <div className="flex items-center mt-2">
                <TrendingDown className="h-4 w-4 text-green-400 mr-1" />
                <span className="text-green-400 text-sm">61 μg/m³ average</span>
              </div>
            </div>
            <MapPin className="h-8 w-8 text-green-400" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/70 text-sm">Satellite Coverage</p>
              <p className="text-2xl font-bold text-white">98.7%</p>
              <div className="flex items-center mt-2">
                <TrendingUp className="h-4 w-4 text-blue-400 mr-1" />
                <span className="text-blue-400 text-sm">+2% this month</span>
              </div>
            </div>
            <Satellite className="h-8 w-8 text-purple-400" />
          </div>
        </motion.div>
      </div>

      {/* Main Trend Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
      >
        <div className="flex items-center space-x-2 mb-6">
          <LineChartIcon className="h-5 w-5 text-white/70" />
          <h3 className="text-lg font-semibold text-white">
            {selectedTimeRange.charAt(0).toUpperCase() + selectedTimeRange.slice(1)} Trends - {selectedMetric.toUpperCase()}
          </h3>
        </div>
        {renderChart()}
      </motion.div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Seasonal Analysis */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
            <PieChartIcon className="h-5 w-5" />
            <span>Seasonal Distribution</span>
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={seasonalData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ season, pm25 }) => `${season}: ${pm25}`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="pm25"
              >
                {seasonalData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#ffffff'
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>

        {/* City Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
            <BarChart3 className="h-5 w-5" />
            <span>Year-over-Year City Comparison</span>
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={cityComparison}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
              <XAxis dataKey="city" stroke="#ffffff70" />
              <YAxis stroke="#ffffff70" />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#ffffff'
                }}
              />
              <Legend />
              <Bar dataKey="pm25_2023" fill="#EF4444" name="2023" />
              <Bar dataKey="pm25_2024" fill="#3B82F6" name="2024" />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Correlation Analysis */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Multi-Parameter Correlation</h3>
        <ResponsiveContainer width="100%" height={400}>
          <ComposedChart data={monthlyTrends}>
            <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
            <XAxis dataKey="month" stroke="#ffffff70" />
            <YAxis yAxisId="left" stroke="#ffffff70" />
            <YAxis yAxisId="right" orientation="right" stroke="#ffffff70" />
            <Tooltip 
              contentStyle={{
                backgroundColor: '#1f2937',
                border: '1px solid #374151',
                borderRadius: '8px',
                color: '#ffffff'
              }}
            />
            <Legend />
            <Bar yAxisId="left" dataKey="pm25" fill="#3B82F6" name="PM2.5 (μg/m³)" />
            <Line yAxisId="right" type="monotone" dataKey="temperature" stroke="#F59E0B" strokeWidth={2} name="Temperature (°C)" />
            <Line yAxisId="right" type="monotone" dataKey="humidity" stroke="#10B981" strokeWidth={2} name="Humidity (%)" />
          </ComposedChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Trend Insights */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Key Insights</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
              <h4 className="text-green-400 font-medium mb-2">Positive Trends</h4>
              <ul className="text-white/80 text-sm space-y-1">
                <li>• Overall 12% reduction in annual PM2.5 levels</li>
                <li>• Bangalore shows consistent improvement (-9%)</li>
                <li>• Summer months maintain good air quality</li>
                <li>• Satellite coverage increased by 2%</li>
              </ul>
            </div>
          </div>
          <div className="space-y-4">
            <div className="p-4 bg-orange-500/10 border border-orange-500/20 rounded-lg">
              <h4 className="text-orange-400 font-medium mb-2">Areas of Concern</h4>
              <ul className="text-white/80 text-sm space-y-1">
                <li>• Winter pollution levels remain critically high</li>
                <li>• Mumbai shows slight increase (+6%)</li>
                <li>• Peak hour pollution during rush times</li>
                <li>• Strong correlation with temperature patterns</li>
              </ul>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};