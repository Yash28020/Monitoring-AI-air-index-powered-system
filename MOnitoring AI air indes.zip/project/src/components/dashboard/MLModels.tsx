import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Brain, 
  TrendingUp, 
  Target, 
  Play, 
  Pause, 
  Settings, 
  Download,
  Upload,
  BarChart3,
  Activity,
  CheckCircle,
  AlertCircle,
  Clock
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  BarChart,
  Bar
} from 'recharts';
import { apiService } from '../../services/api';
import { PredictionModel } from '../../types';

const modelPerformanceData = [
  { epoch: 1, accuracy: 0.65, loss: 0.45 },
  { epoch: 5, accuracy: 0.72, loss: 0.38 },
  { epoch: 10, accuracy: 0.78, loss: 0.32 },
  { epoch: 15, accuracy: 0.82, loss: 0.28 },
  { epoch: 20, accuracy: 0.85, loss: 0.25 },
  { epoch: 25, accuracy: 0.87, loss: 0.23 },
  { epoch: 30, accuracy: 0.89, loss: 0.21 },
];

const validationData = [
  { predicted: 45, actual: 48, residual: -3 },
  { predicted: 67, actual: 65, residual: 2 },
  { predicted: 89, actual: 92, residual: -3 },
  { predicted: 123, actual: 118, residual: 5 },
  { predicted: 156, actual: 159, residual: -3 },
  { predicted: 78, actual: 75, residual: 3 },
  { predicted: 134, actual: 138, residual: -4 },
];

const featureImportance = [
  { feature: 'AOD', importance: 0.35 },
  { feature: 'Temperature', importance: 0.22 },
  { feature: 'Humidity', importance: 0.18 },
  { feature: 'Wind Speed', importance: 0.12 },
  { feature: 'Pressure', importance: 0.08 },
  { feature: 'Solar Radiation', importance: 0.05 },
];

export const MLModels: React.FC = () => {
  const [models, setModels] = useState<PredictionModel[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedModel, setSelectedModel] = useState<string>('');
  const [isTraining, setIsTraining] = useState(false);
  const [trainingProgress, setTrainingProgress] = useState(0);

  useEffect(() => {
    const fetchModels = async () => {
      try {
        const data = await apiService.getModelPerformance();
        setModels(data);
        if (data.length > 0) {
          setSelectedModel(data[0].id);
        }
      } catch (error) {
        console.error('Failed to fetch models:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchModels();
  }, []);

  const handleTrainModel = async () => {
    setIsTraining(true);
    setTrainingProgress(0);
    
    // Simulate training progress
    const interval = setInterval(() => {
      setTrainingProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsTraining(false);
          return 100;
        }
        return prev + 10;
      });
    }, 500);
  };

  const getModelStatusColor = (accuracy: number) => {
    if (accuracy >= 0.85) return 'text-green-400 bg-green-500/20';
    if (accuracy >= 0.75) return 'text-yellow-400 bg-yellow-500/20';
    return 'text-red-400 bg-red-500/20';
  };

  const selectedModelData = models.find(m => m.id === selectedModel);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">ML Model Management</h2>
        <div className="flex items-center space-x-4">
          <select 
            value={selectedModel}
            onChange={(e) => setSelectedModel(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white text-sm"
          >
            {models.map(model => (
              <option key={model.id} value={model.id} className="text-gray-900">
                {model.name}
              </option>
            ))}
          </select>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleTrainModel}
            disabled={isTraining}
            className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 px-4 py-2 rounded-lg text-white transition-colors"
          >
            {isTraining ? <Clock className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
            <span>{isTraining ? 'Training...' : 'Train Model'}</span>
          </motion.button>
        </div>
      </div>

      {/* Model Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {models.map((model, index) => (
          <motion.div
            key={model.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`bg-white/10 backdrop-blur-lg rounded-xl p-6 border transition-all cursor-pointer ${
              selectedModel === model.id ? 'border-blue-400' : 'border-white/20 hover:border-white/30'
            }`}
            onClick={() => setSelectedModel(model.id)}
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <Brain className="h-6 w-6 text-purple-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">{model.name}</h3>
                <p className="text-white/70 text-sm capitalize">{model.algorithm.replace('_', ' ')}</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-white/70">Accuracy</span>
                <span className={`px-2 py-1 rounded text-xs ${getModelStatusColor(model.accuracy)}`}>
                  {(model.accuracy * 100).toFixed(1)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">MAE</span>
                <span className="text-white">{model.mae.toFixed(1)} μg/m³</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">RMSE</span>
                <span className="text-white">{model.rmse.toFixed(1)} μg/m³</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Training Progress */}
      {isTraining && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <h3 className="text-lg font-semibold text-white mb-4">Training Progress</h3>
          <div className="space-y-4">
            <div className="flex justify-between text-white">
              <span>Training Random Forest Model</span>
              <span>{trainingProgress}%</span>
            </div>
            <div className="w-full bg-white/20 rounded-full h-2">
              <div 
                className="bg-blue-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${trainingProgress}%` }}
              ></div>
            </div>
            <div className="text-white/70 text-sm">
              Epoch {Math.floor(trainingProgress / 10)} / 10 - Processing satellite and ground-based data...
            </div>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Model Performance Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
            <TrendingUp className="h-5 w-5" />
            <span>Training Performance</span>
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={modelPerformanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
              <XAxis dataKey="epoch" stroke="#ffffff70" />
              <YAxis stroke="#ffffff70" />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#ffffff'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="accuracy" 
                stroke="#10B981" 
                strokeWidth={2}
                name="Accuracy"
              />
              <Line 
                type="monotone" 
                dataKey="loss" 
                stroke="#EF4444" 
                strokeWidth={2}
                name="Loss"
              />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Feature Importance */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
            <BarChart3 className="h-5 w-5" />
            <span>Feature Importance</span>
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={featureImportance} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
              <XAxis type="number" stroke="#ffffff70" />
              <YAxis dataKey="feature" type="category" stroke="#ffffff70" width={80} />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#ffffff'
                }}
              />
              <Bar dataKey="importance" fill="#8B5CF6" />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Model Validation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
            <Target className="h-5 w-5" />
            <span>Predicted vs Actual</span>
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <ScatterChart data={validationData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
              <XAxis 
                type="number" 
                dataKey="actual" 
                name="Actual PM2.5" 
                stroke="#ffffff70"
                domain={[0, 200]}
              />
              <YAxis 
                type="number" 
                dataKey="predicted" 
                name="Predicted PM2.5" 
                stroke="#ffffff70"
                domain={[0, 200]}
              />
              <Tooltip 
                cursor={{ strokeDasharray: '3 3' }}
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#ffffff'
                }}
              />
              <Scatter dataKey="predicted" fill="#F59E0B" />
              <Line 
                type="linear" 
                dataKey="actual" 
                stroke="#10B981" 
                strokeDasharray="5 5"
              />
            </ScatterChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Model Details */}
        {selectedModelData && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
          >
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
              <Settings className="h-5 w-5" />
              <span>Model Configuration</span>
            </h3>
            <div className="space-y-4">
              <div>
                <h4 className="text-white font-medium mb-2">Input Features</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedModelData.features.map((feature, index) => (
                    <span 
                      key={index}
                      className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-sm"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-white font-medium mb-2">Performance Metrics</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white/5 rounded-lg p-3">
                    <p className="text-white/70 text-sm">R² Score</p>
                    <p className="text-white font-semibold">{selectedModelData.accuracy.toFixed(3)}</p>
                  </div>
                  <div className="bg-white/5 rounded-lg p-3">
                    <p className="text-white/70 text-sm">MAE</p>
                    <p className="text-white font-semibold">{selectedModelData.mae.toFixed(1)} μg/m³</p>
                  </div>
                  <div className="bg-white/5 rounded-lg p-3">
                    <p className="text-white/70 text-sm">RMSE</p>
                    <p className="text-white font-semibold">{selectedModelData.rmse.toFixed(1)} μg/m³</p>
                  </div>
                  <div className="bg-white/5 rounded-lg p-3">
                    <p className="text-white/70 text-sm">Last Trained</p>
                    <p className="text-white font-semibold">
                      {new Date(selectedModelData.last_trained).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Model Evaluation Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Model Evaluation Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <CheckCircle className="h-8 w-8 text-green-400" />
            </div>
            <p className="text-2xl font-bold text-white">87.3%</p>
            <p className="text-white/70 text-sm">Average Model Accuracy</p>
            <p className="text-green-400 text-sm">Exceeds target threshold</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Activity className="h-8 w-8 text-blue-400" />
            </div>
            <p className="text-2xl font-bold text-white">15.2</p>
            <p className="text-white/70 text-sm">Mean Absolute Error (μg/m³)</p>
            <p className="text-blue-400 text-sm">Within acceptable range</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <AlertCircle className="h-8 w-8 text-orange-400" />
            </div>
            <p className="text-2xl font-bold text-white">0.89</p>
            <p className="text-white/70 text-sm">AOD-PM2.5 Correlation</p>
            <p className="text-orange-400 text-sm">Strong relationship confirmed</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};