import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Database, 
  Satellite, 
  MapPin, 
  Cloud, 
  RefreshCw, 
  Download, 
  Upload,
  Settings,
  CheckCircle,
  AlertCircle,
  Clock,
  Activity,
  Globe,
  Wifi,
  WifiOff,
  Eye,
  Filter
} from 'lucide-react';

interface DataSource {
  id: string;
  name: string;
  type: 'satellite' | 'ground' | 'reanalysis' | 'model';
  status: 'online' | 'offline' | 'maintenance' | 'error';
  lastUpdate: string;
  dataPoints: number;
  coverage: number;
  latency: number;
  accuracy: number;
  description: string;
  provider: string;
  frequency: string;
}

export const DataSources: React.FC = () => {
  const [dataSources, setDataSources] = useState<DataSource[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  useEffect(() => {
    const fetchDataSources = async () => {
      try {
        // Mock data for demonstration
        const mockSources: DataSource[] = [
          {
            id: '1',
            name: 'INSAT-3D AOD',
            type: 'satellite',
            status: 'online',
            lastUpdate: new Date(Date.now() - 1800000).toISOString(),
            dataPoints: 125000,
            coverage: 98.5,
            latency: 45,
            accuracy: 92.3,
            description: 'Aerosol Optical Depth measurements from INSAT-3D satellite',
            provider: 'ISRO',
            frequency: 'Every 30 minutes'
          },
          {
            id: '2',
            name: 'INSAT-3DR AOD',
            type: 'satellite',
            status: 'online',
            lastUpdate: new Date(Date.now() - 900000).toISOString(),
            dataPoints: 98000,
            coverage: 95.2,
            latency: 38,
            accuracy: 94.1,
            description: 'High-resolution AOD data from INSAT-3DR',
            provider: 'ISRO',
            frequency: 'Every 15 minutes'
          },
          {
            id: '3',
            name: 'INSAT-3DS AOD',
            type: 'satellite',
            status: 'maintenance',
            lastUpdate: new Date(Date.now() - 21600000).toISOString(),
            dataPoints: 67000,
            coverage: 78.9,
            latency: 120,
            accuracy: 89.7,
            description: 'Backup AOD measurements from INSAT-3DS',
            provider: 'ISRO',
            frequency: 'Every 1 hour'
          },
          {
            id: '4',
            name: 'CPCB Ground Stations',
            type: 'ground',
            status: 'online',
            lastUpdate: new Date(Date.now() - 300000).toISOString(),
            dataPoints: 45000,
            coverage: 87.3,
            latency: 15,
            accuracy: 98.5,
            description: 'Real-time PM2.5 and PM10 measurements from CPCB monitoring stations',
            provider: 'Central Pollution Control Board',
            frequency: 'Every 15 minutes'
          },
          {
            id: '5',
            name: 'State Board Stations',
            type: 'ground',
            status: 'online',
            lastUpdate: new Date(Date.now() - 600000).toISOString(),
            dataPoints: 23000,
            coverage: 65.8,
            latency: 25,
            accuracy: 95.2,
            description: 'Additional ground-based monitoring from state pollution control boards',
            provider: 'State PCBs',
            frequency: 'Every 30 minutes'
          },
          {
            id: '6',
            name: 'MERRA-2 Reanalysis',
            type: 'reanalysis',
            status: 'online',
            lastUpdate: new Date(Date.now() - 10800000).toISOString(),
            dataPoints: 156000,
            coverage: 100,
            latency: 180,
            accuracy: 91.8,
            description: 'Atmospheric reanalysis data including meteorological variables',
            provider: 'NASA GMAO',
            frequency: 'Every 3 hours'
          },
          {
            id: '7',
            name: 'ERA5 Reanalysis',
            type: 'reanalysis',
            status: 'online',
            lastUpdate: new Date(Date.now() - 7200000).toISOString(),
            dataPoints: 189000,
            coverage: 100,
            latency: 120,
            accuracy: 93.4,
            description: 'High-resolution atmospheric reanalysis from ECMWF',
            provider: 'ECMWF',
            frequency: 'Every 1 hour'
          },
          {
            id: '8',
            name: 'ML Prediction Engine',
            type: 'model',
            status: 'online',
            lastUpdate: new Date(Date.now() - 1800000).toISOString(),
            dataPoints: 78000,
            coverage: 92.1,
            latency: 60,
            accuracy: 87.6,
            description: 'AI/ML generated PM concentration predictions',
            provider: 'AirSight Platform',
            frequency: 'Every 30 minutes'
          },
          {
            id: '9',
            name: 'Traffic Data API',
            type: 'model',
            status: 'error',
            lastUpdate: new Date(Date.now() - 43200000).toISOString(),
            dataPoints: 12000,
            coverage: 45.2,
            latency: 300,
            accuracy: 76.3,
            description: 'Real-time traffic density data for correlation analysis',
            provider: 'Google Maps API',
            frequency: 'Every 5 minutes'
          }
        ];
        
        setDataSources(mockSources);
      } catch (error) {
        console.error('Failed to fetch data sources:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDataSources();
    const interval = setInterval(fetchDataSources, 60000);
    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'text-green-400 bg-green-500/20';
      case 'offline': return 'text-red-400 bg-red-500/20';
      case 'maintenance': return 'text-yellow-400 bg-yellow-500/20';
      case 'error': return 'text-orange-400 bg-orange-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'satellite': return <Satellite className="h-5 w-5" />;
      case 'ground': return <MapPin className="h-5 w-5" />;
      case 'reanalysis': return <Cloud className="h-5 w-5" />;
      case 'model': return <Activity className="h-5 w-5" />;
      default: return <Database className="h-5 w-5" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online': return <CheckCircle className="h-4 w-4" />;
      case 'offline': return <WifiOff className="h-4 w-4" />;
      case 'maintenance': return <Clock className="h-4 w-4" />;
      case 'error': return <AlertCircle className="h-4 w-4" />;
      default: return <Wifi className="h-4 w-4" />;
    }
  };

  const filteredSources = dataSources.filter(source => {
    const matchesType = selectedType === 'all' || source.type === selectedType;
    const matchesStatus = selectedStatus === 'all' || source.status === selectedStatus;
    return matchesType && matchesStatus;
  });

  const getTypeStats = () => {
    const stats = {
      satellite: { total: 0, online: 0 },
      ground: { total: 0, online: 0 },
      reanalysis: { total: 0, online: 0 },
      model: { total: 0, online: 0 }
    };

    dataSources.forEach(source => {
      stats[source.type].total++;
      if (source.status === 'online') {
        stats[source.type].online++;
      }
    });

    return stats;
  };

  const typeStats = getTypeStats();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Data Sources</h2>
        <div className="flex items-center space-x-4">
          <select 
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white text-sm"
          >
            <option value="all" className="text-gray-900">All Types</option>
            <option value="satellite" className="text-gray-900">Satellite</option>
            <option value="ground" className="text-gray-900">Ground Stations</option>
            <option value="reanalysis" className="text-gray-900">Reanalysis</option>
            <option value="model" className="text-gray-900">Model/API</option>
          </select>
          <select 
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white text-sm"
          >
            <option value="all" className="text-gray-900">All Status</option>
            <option value="online" className="text-gray-900">Online</option>
            <option value="offline" className="text-gray-900">Offline</option>
            <option value="maintenance" className="text-gray-900">Maintenance</option>
            <option value="error" className="text-gray-900">Error</option>
          </select>
          <button className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-lg text-white transition-colors">
            <RefreshCw className="h-4 w-4" />
            <span>Refresh All</span>
          </button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {Object.entries(typeStats).map(([type, stats]) => (
          <motion.div
            key={type}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                {getTypeIcon(type)}
              </div>
              <h3 className="text-lg font-semibold text-white capitalize">{type}</h3>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-white/70">Total Sources</span>
                <span className="text-white font-semibold">{stats.total}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">Online</span>
                <span className="text-green-400 font-semibold">{stats.online}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">Uptime</span>
                <span className="text-white font-semibold">
                  {stats.total > 0 ? ((stats.online / stats.total) * 100).toFixed(1) : 0}%
                </span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Data Sources List */}
      <div className="space-y-4">
        {filteredSources.map((source, index) => (
          <motion.div
            key={source.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 hover:border-white/30 transition-all"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-4 flex-1">
                <div className="p-3 bg-blue-500/20 rounded-lg">
                  {getTypeIcon(source.type)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-lg font-semibold text-white">{source.name}</h3>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center space-x-1 ${getStatusColor(source.status)}`}>
                      {getStatusIcon(source.status)}
                      <span className="capitalize">{source.status}</span>
                    </span>
                    <span className="px-2 py-1 bg-white/10 rounded text-xs text-white/70 capitalize">
                      {source.type}
                    </span>
                  </div>
                  <p className="text-white/80 mb-4">{source.description}</p>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <p className="text-white/60 text-xs">Data Points</p>
                      <p className="text-white font-semibold">{source.dataPoints.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-white/60 text-xs">Coverage</p>
                      <p className="text-white font-semibold">{source.coverage.toFixed(1)}%</p>
                    </div>
                    <div>
                      <p className="text-white/60 text-xs">Latency</p>
                      <p className="text-white font-semibold">{source.latency}min</p>
                    </div>
                    <div>
                      <p className="text-white/60 text-xs">Accuracy</p>
                      <p className="text-white font-semibold">{source.accuracy.toFixed(1)}%</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-6 text-sm text-white/60">
                    <div className="flex items-center space-x-1">
                      <Globe className="h-4 w-4" />
                      <span>{source.provider}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <RefreshCw className="h-4 w-4" />
                      <span>{source.frequency}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>Updated {new Date(source.lastUpdate).toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <button className="p-2 text-white/70 hover:text-white transition-colors">
                  <Eye className="h-4 w-4" />
                </button>
                <button className="p-2 text-white/70 hover:text-white transition-colors">
                  <Download className="h-4 w-4" />
                </button>
                <button className="p-2 text-white/70 hover:text-white transition-colors">
                  <Settings className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Progress Bars */}
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/70">Coverage</span>
                <span className="text-white">{source.coverage.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-white/20 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${source.coverage}%` }}
                ></div>
              </div>
              
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/70">Accuracy</span>
                <span className="text-white">{source.accuracy.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-white/20 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all duration-300 ${
                    source.accuracy >= 90 ? 'bg-green-500' : 
                    source.accuracy >= 80 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${source.accuracy}%` }}
                ></div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Data Integration Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Data Integration Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <p className="text-3xl font-bold text-white">
              {dataSources.reduce((sum, source) => sum + source.dataPoints, 0).toLocaleString()}
            </p>
            <p className="text-white/70 text-sm">Total Data Points</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-white">
              {(dataSources.reduce((sum, source) => sum + source.coverage, 0) / dataSources.length).toFixed(1)}%
            </p>
            <p className="text-white/70 text-sm">Average Coverage</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-white">
              {dataSources.filter(source => source.status === 'online').length}/{dataSources.length}
            </p>
            <p className="text-white/70 text-sm">Sources Online</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};