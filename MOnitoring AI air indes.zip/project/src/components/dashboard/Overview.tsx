import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Activity, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown,
  Eye,
  Satellite,
  MapPin,
  Database
} from 'lucide-react';
import { apiService } from '../../services/api';
import { AirQualityData } from '../../types';

const StatCard: React.FC<{
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: React.ReactNode;
  color: string;
}> = ({ title, value, change, trend, icon, color }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 hover:border-white/30 transition-all duration-300"
  >
    <div className="flex items-center justify-between">
      <div>
        <p className="text-white/70 text-sm font-medium">{title}</p>
        <p className="text-2xl font-bold text-white mt-1">{value}</p>
        <div className="flex items-center mt-2">
          {trend === 'up' ? (
            <TrendingUp className="h-4 w-4 text-red-400 mr-1" />
          ) : (
            <TrendingDown className="h-4 w-4 text-green-400 mr-1" />
          )}
          <span className={`text-sm ${trend === 'up' ? 'text-red-400' : 'text-green-400'}`}>
            {change}
          </span>
        </div>
      </div>
      <div className={`p-3 rounded-lg ${color}`}>
        {icon}
      </div>
    </div>
  </motion.div>
);

export const Overview: React.FC = () => {
  const [airQualityData, setAirQualityData] = useState<AirQualityData[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await apiService.fetchAirQualityData();
        setAirQualityData(data);
      } catch (error) {
        console.error('Failed to fetch air quality data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const getAQILevel = (pm25: number) => {
    if (pm25 <= 30) return { level: 'Good', color: 'text-green-400' };
    if (pm25 <= 60) return { level: 'Moderate', color: 'text-yellow-400' };
    if (pm25 <= 90) return { level: 'Poor', color: 'text-orange-400' };
    if (pm25 <= 120) return { level: 'Very Poor', color: 'text-red-400' };
    return { level: 'Severe', color: 'text-purple-400' };
  };

  const averagePM25 = airQualityData.reduce((sum, data) => sum + data.pm25, 0) / airQualityData.length || 0;
  const severeStations = airQualityData.filter(data => data.pm25 > 120).length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Air Quality Overview</h2>
        <div className="flex items-center space-x-2 text-white/70">
          <Activity className="h-5 w-5" />
          <span className="text-sm">Live Data</span>
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <StatCard
          title="Average PM2.5"
          value={`${averagePM25.toFixed(0)} μg/m³`}
          change="+12% from yesterday"
          trend="up"
          icon={<Activity className="h-6 w-6 text-white" />}
          color="bg-blue-500/20"
        />
        <StatCard
          title="Severe Stations"
          value={severeStations.toString()}
          change="2 new alerts"
          trend="up"
          icon={<AlertTriangle className="h-6 w-6 text-white" />}
          color="bg-red-500/20"
        />
        <StatCard
          title="Active Monitors"
          value={airQualityData.length.toString()}
          change="98% uptime"
          trend="down"
          icon={<Eye className="h-6 w-6 text-white" />}
          color="bg-green-500/20"
        />
        <StatCard
          title="Satellite Passes"
          value="24"
          change="+3 today"
          trend="up"
          icon={<Satellite className="h-6 w-6 text-white" />}
          color="bg-purple-500/20"
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <h3 className="text-lg font-semibold text-white mb-4">Current Air Quality Status</h3>
          <div className="space-y-4">
            {airQualityData.slice(0, 5).map((data, index) => {
              const aqi = getAQILevel(data.pm25);
              return (
                <div key={data.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-5 w-5 text-white/70" />
                    <div>
                      <p className="text-white font-medium">{data.location.name}</p>
                      <p className="text-white/70 text-sm">{data.location.state}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-semibold">{data.pm25.toFixed(0)} μg/m³</p>
                    <p className={`text-sm ${aqi.color}`}>{aqi.level}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <h3 className="text-lg font-semibold text-white mb-4">System Health</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-white/70">Satellite Data Feed</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span className="text-green-400 text-sm">Online</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white/70">Ground Stations</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span className="text-green-400 text-sm">98% Active</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white/70">ML Prediction Engine</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span className="text-green-400 text-sm">Running</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white/70">Data Processing</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                <span className="text-yellow-400 text-sm">Processing</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Recent Alerts</h3>
        <div className="space-y-3">
          <div className="flex items-center space-x-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
            <AlertTriangle className="h-5 w-5 text-red-400" />
            <div className="flex-1">
              <p className="text-white font-medium">Severe air quality detected in Delhi</p>
              <p className="text-white/70 text-sm">PM2.5 levels exceeded 300 μg/m³</p>
            </div>
            <span className="text-white/70 text-sm">2 min ago</span>
          </div>
          <div className="flex items-center space-x-4 p-3 bg-orange-500/10 border border-orange-500/20 rounded-lg">
            <AlertTriangle className="h-5 w-5 text-orange-400" />
            <div className="flex-1">
              <p className="text-white font-medium">High PM10 levels in Mumbai</p>
              <p className="text-white/70 text-sm">Above WHO recommended limits</p>
            </div>
            <span className="text-white/70 text-sm">15 min ago</span>
          </div>
          <div className="flex items-center space-x-4 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
            <Database className="h-5 w-5 text-yellow-400" />
            <div className="flex-1">
              <p className="text-white font-medium">Satellite data processing complete</p>
              <p className="text-white/70 text-sm">Latest INSAT-3D observations integrated</p>
            </div>
            <span className="text-white/70 text-sm">1 hour ago</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
};