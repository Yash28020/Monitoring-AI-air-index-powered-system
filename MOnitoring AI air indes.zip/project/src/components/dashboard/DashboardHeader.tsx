import React from 'react';
import { motion } from 'framer-motion';
import { Bell, User, LogOut, Settings } from 'lucide-react';
import { useAuth } from '../auth/AuthProvider';

export const DashboardHeader: React.FC = () => {
  const { user, logout } = useAuth();

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white/10 backdrop-blur-lg border-b border-white/20 px-6 py-4"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">AS</span>
            </div>
            <h1 className="text-2xl font-bold text-white">AirSight</h1>
          </div>
          <div className="hidden md:flex items-center space-x-2 text-white/70">
            <span className="text-sm">Real-time Air Quality Monitoring</span>
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="relative p-2 text-white/70 hover:text-white transition-colors"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
              3
            </span>
          </motion.button>

          <div className="relative group">
            <motion.button
              whileHover={{ scale: 1.05 }}
              className="flex items-center space-x-2 bg-white/10 rounded-lg px-3 py-2 text-white/90 hover:bg-white/20 transition-colors"
            >
              <User className="h-4 w-4" />
              <span className="hidden md:inline text-sm">{user?.name}</span>
            </motion.button>

            <div className="absolute right-0 mt-2 w-48 bg-white/10 backdrop-blur-lg rounded-lg border border-white/20 py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
              <a href="#" className="block px-4 py-2 text-sm text-white/90 hover:bg-white/10 flex items-center space-x-2">
                <Settings className="h-4 w-4" />
                <span>Settings</span>
              </a>
              <button
                onClick={logout}
                className="block w-full text-left px-4 py-2 text-sm text-white/90 hover:bg-white/10 flex items-center space-x-2"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.header>
  );
};