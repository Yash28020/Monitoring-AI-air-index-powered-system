import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Satellite, 
  Download, 
  RefreshCw, 
  Calendar, 
  MapPin, 
  Cloud, 
  Eye,
  Filter,
  Grid,
  Layers
} from 'lucide-react';
import { apiService } from '../../services/api';
import { SatelliteData } from '../../types';

export const SatelliteDataComponent: React.FC = () => {
  const [satelliteData, setSatelliteData] = useState<SatelliteData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedSatellite, setSelectedSatellite] = useState<string>('all');
  const [dateRange, setDateRange] = useState('today');
  const [qualityFilter, setQualityFilter] = useState<string>('all');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await apiService.fetchSatelliteData();
        setSatelliteData(data);
      } catch (error) {
        console.error('Failed to fetch satellite data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 60000);
    return () => clearInterval(interval);
  }, []);

  const getQualityColor = (quality: string) => {
    switch (quality) {
      case 'good': return 'text-green-400 bg-green-500/20';
      case 'moderate': return 'text-yellow-400 bg-yellow-500/20';
      case 'poor': return 'text-red-400 bg-red-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  const filteredData = satelliteData.filter(data => {
    if (selectedSatellite !== 'all' && data.satellite !== selectedSatellite) return false;
    if (qualityFilter !== 'all' && data.quality_flag !== qualityFilter) return false;
    return true;
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Satellite Data Management</h2>
        <div className="flex items-center space-x-4">
          <select 
            value={selectedSatellite}
            onChange={(e) => setSelectedSatellite(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white text-sm"
          >
            <option value="all" className="text-gray-900">All Satellites</option>
            <option value="INSAT-3D" className="text-gray-900">INSAT-3D</option>
            <option value="INSAT-3DR" className="text-gray-900">INSAT-3DR</option>
            <option value="INSAT-3DS" className="text-gray-900">INSAT-3DS</option>
          </select>
          <select 
            value={qualityFilter}
            onChange={(e) => setQualityFilter(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white text-sm"
          >
            <option value="all" className="text-gray-900">All Quality</option>
            <option value="good" className="text-gray-900">Good</option>
            <option value="moderate" className="text-gray-900">Moderate</option>
            <option value="poor" className="text-gray-900">Poor</option>
          </select>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-lg text-white transition-colors"
          >
            <Download className="h-4 w-4" />
            <span>Export Data</span>
          </motion.button>
        </div>
      </div>

      {/* Satellite Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-blue-500/20 rounded-lg">
              <Satellite className="h-6 w-6 text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold text-white">INSAT-3D</h3>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-white/70">Status</span>
              <span className="text-green-400">Active</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/70">Last Pass</span>
              <span className="text-white">2 hours ago</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/70">AOD Coverage</span>
              <span className="text-white">85%</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-green-500/20 rounded-lg">
              <Satellite className="h-6 w-6 text-green-400" />
            </div>
            <h3 className="text-lg font-semibold text-white">INSAT-3DR</h3>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-white/70">Status</span>
              <span className="text-green-400">Active</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/70">Last Pass</span>
              <span className="text-white">1 hour ago</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/70">AOD Coverage</span>
              <span className="text-white">92%</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-yellow-500/20 rounded-lg">
              <Satellite className="h-6 w-6 text-yellow-400" />
            </div>
            <h3 className="text-lg font-semibold text-white">INSAT-3DS</h3>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-white/70">Status</span>
              <span className="text-yellow-400">Standby</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/70">Last Pass</span>
              <span className="text-white">6 hours ago</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/70">AOD Coverage</span>
              <span className="text-white">78%</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* AOD Spatial Map */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-white flex items-center space-x-2">
            <Grid className="h-5 w-5" />
            <span>AOD Spatial Distribution</span>
          </h3>
          <div className="flex items-center space-x-2">
            <button className="p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-colors">
              <Layers className="h-4 w-4" />
            </button>
            <button className="p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-colors">
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>
        </div>
        
        <div className="relative h-96 bg-gradient-to-br from-blue-900/20 to-purple-900/20 rounded-lg overflow-hidden">
          {/* Simulated AOD Heat Map */}
          <div className="absolute inset-0">
            {/* High AOD regions (red/orange) */}
            <div className="absolute top-1/4 left-1/3 w-24 h-16 bg-red-500/60 rounded-full blur-lg"></div>
            <div className="absolute top-1/3 left-1/2 w-32 h-20 bg-orange-500/50 rounded-full blur-lg"></div>
            
            {/* Medium AOD regions (yellow) */}
            <div className="absolute top-1/2 right-1/3 w-28 h-18 bg-yellow-500/40 rounded-full blur-lg"></div>
            <div className="absolute bottom-1/3 left-1/4 w-20 h-14 bg-yellow-500/35 rounded-full blur-lg"></div>
            
            {/* Low AOD regions (green/blue) */}
            <div className="absolute bottom-1/4 right-1/4 w-16 h-12 bg-green-500/30 rounded-full blur-lg"></div>
            <div className="absolute top-1/6 right-1/6 w-18 h-14 bg-blue-500/25 rounded-full blur-lg"></div>
          </div>
          
          {/* AOD Scale Legend */}
          <div className="absolute bottom-4 left-4 bg-white/10 backdrop-blur-lg rounded-lg p-3 border border-white/20">
            <h4 className="text-white font-medium text-sm mb-2">AOD Scale</h4>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-blue-500 rounded"></div>
              <span className="text-white/70 text-xs">0.0-0.2</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-green-500 rounded"></div>
              <span className="text-white/70 text-xs">0.2-0.4</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-yellow-500 rounded"></div>
              <span className="text-white/70 text-xs">0.4-0.6</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-orange-500 rounded"></div>
              <span className="text-white/70 text-xs">0.6-0.8</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-red-500 rounded"></div>
              <span className="text-white/70 text-xs">0.8+</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Satellite Data Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Recent Satellite Observations</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-white">
            <thead>
              <tr className="border-b border-white/20">
                <th className="text-left py-3 px-4">Satellite</th>
                <th className="text-left py-3 px-4">AOD Value</th>
                <th className="text-left py-3 px-4">Location</th>
                <th className="text-left py-3 px-4">Cloud Cover</th>
                <th className="text-left py-3 px-4">Quality</th>
                <th className="text-left py-3 px-4">Timestamp</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.slice(0, 10).map((data, index) => (
                <tr key={data.id} className="border-b border-white/10 hover:bg-white/5">
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-2">
                      <Satellite className="h-4 w-4 text-white/70" />
                      <span>{data.satellite}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono">{data.aod_value.toFixed(3)}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-1">
                      <MapPin className="h-3 w-3 text-white/70" />
                      <span className="text-sm">{data.coordinates[0].toFixed(2)}, {data.coordinates[1].toFixed(2)}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-1">
                      <Cloud className="h-3 w-3 text-white/70" />
                      <span>{data.cloud_cover}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-1 rounded text-xs ${getQualityColor(data.quality_flag)}`}>
                      {data.quality_flag}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-sm text-white/70">
                    {new Date(data.timestamp).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
};