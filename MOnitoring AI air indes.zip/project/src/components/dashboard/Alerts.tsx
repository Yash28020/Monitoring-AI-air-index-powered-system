import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  AlertTriangle, 
  Bell, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Filter,
  Search,
  Download,
  Settings,
  MapPin,
  Satellite,
  Activity,
  Database,
  RefreshCw
} from 'lucide-react';
import { apiService } from '../../services/api';

interface Alert {
  id: string;
  type: 'pm_threshold' | 'aqi_severe' | 'satellite_anomaly' | 'model_drift' | 'system_error';
  title: string;
  message: string;
  location?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: string;
  acknowledged: boolean;
  value?: number;
  threshold?: number;
}

export const Alerts: React.FC = () => {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [filteredAlerts, setFilteredAlerts] = useState<Alert[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [showAcknowledged, setShowAcknowledged] = useState(false);

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        // Simulate API call with mock data
        const mockAlerts: Alert[] = [
          {
            id: '1',
            type: 'pm_threshold',
            title: 'Severe PM2.5 Levels Detected',
            message: 'PM2.5 concentration has exceeded 300 μg/m³ in Delhi NCR region',
            location: 'Delhi, India',
            severity: 'critical',
            timestamp: new Date(Date.now() - 300000).toISOString(),
            acknowledged: false,
            value: 312,
            threshold: 300
          },
          {
            id: '2',
            type: 'aqi_severe',
            title: 'AQI Reaches Severe Category',
            message: 'Air Quality Index has reached severe levels (AQI > 400) in multiple locations',
            location: 'Mumbai, Maharashtra',
            severity: 'critical',
            timestamp: new Date(Date.now() - 900000).toISOString(),
            acknowledged: false,
            value: 425,
            threshold: 400
          },
          {
            id: '3',
            type: 'satellite_anomaly',
            title: 'INSAT-3D Data Anomaly',
            message: 'Unusual AOD readings detected in satellite data - possible cloud contamination',
            severity: 'medium',
            timestamp: new Date(Date.now() - 1800000).toISOString(),
            acknowledged: true
          },
          {
            id: '4',
            type: 'model_drift',
            title: 'ML Model Performance Degradation',
            message: 'Random Forest model accuracy has dropped below 85% threshold',
            severity: 'high',
            timestamp: new Date(Date.now() - 3600000).toISOString(),
            acknowledged: false,
            value: 82,
            threshold: 85
          },
          {
            id: '5',
            type: 'pm_threshold',
            title: 'High PM10 Concentration',
            message: 'PM10 levels exceeding WHO guidelines in Bangalore',
            location: 'Bangalore, Karnataka',
            severity: 'medium',
            timestamp: new Date(Date.now() - 7200000).toISOString(),
            acknowledged: true,
            value: 165,
            threshold: 150
          },
          {
            id: '6',
            type: 'system_error',
            title: 'Data Processing Delay',
            message: 'CPCB data ingestion experiencing delays - some stations may show outdated information',
            severity: 'low',
            timestamp: new Date(Date.now() - 10800000).toISOString(),
            acknowledged: false
          }
        ];
        
        setAlerts(mockAlerts);
        setFilteredAlerts(mockAlerts);
      } catch (error) {
        console.error('Failed to fetch alerts:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAlerts();
    const interval = setInterval(fetchAlerts, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    let filtered = alerts.filter(alert => {
      const matchesSearch = alert.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           alert.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           (alert.location && alert.location.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesSeverity = severityFilter === 'all' || alert.severity === severityFilter;
      const matchesType = typeFilter === 'all' || alert.type === typeFilter;
      const matchesAcknowledged = showAcknowledged || !alert.acknowledged;

      return matchesSearch && matchesSeverity && matchesType && matchesAcknowledged;
    });

    setFilteredAlerts(filtered);
  }, [alerts, searchTerm, severityFilter, typeFilter, showAcknowledged]);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-400 bg-red-500/20 border-red-500/30';
      case 'high': return 'text-orange-400 bg-orange-500/20 border-orange-500/30';
      case 'medium': return 'text-yellow-400 bg-yellow-500/20 border-yellow-500/30';
      case 'low': return 'text-blue-400 bg-blue-500/20 border-blue-500/30';
      default: return 'text-gray-400 bg-gray-500/20 border-gray-500/30';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'pm_threshold': return <Activity className="h-5 w-5" />;
      case 'aqi_severe': return <AlertTriangle className="h-5 w-5" />;
      case 'satellite_anomaly': return <Satellite className="h-5 w-5" />;
      case 'model_drift': return <Database className="h-5 w-5" />;
      case 'system_error': return <XCircle className="h-5 w-5" />;
      default: return <Bell className="h-5 w-5" />;
    }
  };

  const acknowledgeAlert = (alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, acknowledged: true } : alert
    ));
  };

  const acknowledgeAll = () => {
    setAlerts(prev => prev.map(alert => ({ ...alert, acknowledged: true })));
  };

  const unacknowledgedCount = alerts.filter(alert => !alert.acknowledged).length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Alert Management</h2>
          <p className="text-white/70">
            {unacknowledgedCount} unacknowledged alerts • {alerts.length} total alerts
          </p>
        </div>
        <div className="flex items-center space-x-4">
          {unacknowledgedCount > 0 && (
            <button
              onClick={acknowledgeAll}
              className="flex items-center space-x-2 bg-green-500 hover:bg-green-600 px-4 py-2 rounded-lg text-white transition-colors"
            >
              <CheckCircle className="h-4 w-4" />
              <span>Acknowledge All</span>
            </button>
          )}
          <button className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-lg text-white transition-colors">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </button>
          <button className="flex items-center space-x-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg text-white transition-colors">
            <Settings className="h-4 w-4" />
            <span>Configure</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40 h-4 w-4" />
            <input
              type="text"
              placeholder="Search alerts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all" className="text-gray-900">All Severities</option>
            <option value="critical" className="text-gray-900">Critical</option>
            <option value="high" className="text-gray-900">High</option>
            <option value="medium" className="text-gray-900">Medium</option>
            <option value="low" className="text-gray-900">Low</option>
          </select>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all" className="text-gray-900">All Types</option>
            <option value="pm_threshold" className="text-gray-900">PM Threshold</option>
            <option value="aqi_severe" className="text-gray-900">AQI Severe</option>
            <option value="satellite_anomaly" className="text-gray-900">Satellite Anomaly</option>
            <option value="model_drift" className="text-gray-900">Model Drift</option>
            <option value="system_error" className="text-gray-900">System Error</option>
          </select>
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={showAcknowledged}
              onChange={(e) => setShowAcknowledged(e.target.checked)}
              className="rounded border-white/20 bg-white/10 text-blue-500 focus:ring-blue-500"
            />
            <span className="text-white/70 text-sm">Show Acknowledged</span>
          </label>
        </div>
      </div>

      {/* Alert Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {['critical', 'high', 'medium', 'low'].map((severity) => {
          const count = alerts.filter(alert => alert.severity === severity && !alert.acknowledged).length;
          return (
            <motion.div
              key={severity}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`bg-white/10 backdrop-blur-lg rounded-xl p-6 border ${getSeverityColor(severity)}`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-sm capitalize">{severity} Alerts</p>
                  <p className="text-2xl font-bold text-white">{count}</p>
                </div>
                <AlertTriangle className={`h-8 w-8 ${severity === 'critical' ? 'text-red-400' : severity === 'high' ? 'text-orange-400' : severity === 'medium' ? 'text-yellow-400' : 'text-blue-400'}`} />
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.length === 0 ? (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-12 border border-white/20 text-center">
            <Bell className="h-12 w-12 text-white/50 mx-auto mb-4" />
            <p className="text-white/70">No alerts match your current filters</p>
          </div>
        ) : (
          filteredAlerts.map((alert, index) => (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`bg-white/10 backdrop-blur-lg rounded-xl p-6 border transition-all ${
                alert.acknowledged ? 'border-white/10 opacity-60' : getSeverityColor(alert.severity)
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4 flex-1">
                  <div className={`p-2 rounded-lg ${getSeverityColor(alert.severity)}`}>
                    {getTypeIcon(alert.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <h3 className="text-lg font-semibold text-white">{alert.title}</h3>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${getSeverityColor(alert.severity)}`}>
                        {alert.severity.toUpperCase()}
                      </span>
                      {alert.acknowledged && (
                        <span className="px-2 py-1 rounded text-xs bg-green-500/20 text-green-400">
                          ACKNOWLEDGED
                        </span>
                      )}
                    </div>
                    <p className="text-white/80 mb-3">{alert.message}</p>
                    <div className="flex items-center space-x-4 text-sm text-white/60">
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{new Date(alert.timestamp).toLocaleString()}</span>
                      </div>
                      {alert.location && (
                        <div className="flex items-center space-x-1">
                          <MapPin className="h-4 w-4" />
                          <span>{alert.location}</span>
                        </div>
                      )}
                      {alert.value && alert.threshold && (
                        <div className="flex items-center space-x-1">
                          <Activity className="h-4 w-4" />
                          <span>{alert.value} / {alert.threshold}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {!alert.acknowledged && (
                    <button
                      onClick={() => acknowledgeAlert(alert.id)}
                      className="flex items-center space-x-1 bg-green-500 hover:bg-green-600 px-3 py-1 rounded text-white text-sm transition-colors"
                    >
                      <CheckCircle className="h-4 w-4" />
                      <span>Acknowledge</span>
                    </button>
                  )}
                  <button className="p-2 text-white/70 hover:text-white transition-colors">
                    <Settings className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};