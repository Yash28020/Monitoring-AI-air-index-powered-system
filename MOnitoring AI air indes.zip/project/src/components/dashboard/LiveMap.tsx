import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Satellite, Filter, RefreshCw, Layers } from 'lucide-react';
import { apiService } from '../../services/api';
import { AirQualityData } from '../../types';

interface MapMarker {
  id: string;
  position: [number, number];
  pm25: number;
  location: string;
  predicted: boolean;
}

export const LiveMap: React.FC = () => {
  const [airQualityData, setAirQualityData] = useState<AirQualityData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedMarker, setSelectedMarker] = useState<MapMarker | null>(null);
  const [showPredicted, setShowPredicted] = useState(true);
  const [showSatellite, setShowSatellite] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await apiService.fetchAirQualityData();
        setAirQualityData(data);
      } catch (error) {
        console.error('Failed to fetch air quality data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, []);

  const getMarkerColor = (pm25: number) => {
    if (pm25 <= 30) return 'bg-green-500';
    if (pm25 <= 60) return 'bg-yellow-500';
    if (pm25 <= 90) return 'bg-orange-500';
    if (pm25 <= 120) return 'bg-red-500';
    return 'bg-purple-500';
  };

  const getAQILevel = (pm25: number) => {
    if (pm25 <= 30) return 'Good';
    if (pm25 <= 60) return 'Moderate';
    if (pm25 <= 90) return 'Poor';
    if (pm25 <= 120) return 'Very Poor';
    return 'Severe';
  };

  const markers: MapMarker[] = airQualityData.map(data => ({
    id: data.id,
    position: [data.location.lat, data.location.lng],
    pm25: data.pm25,
    location: data.location.name,
    predicted: data.predicted,
  }));

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Live Air Quality Map</h2>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="predicted"
              checked={showPredicted}
              onChange={(e) => setShowPredicted(e.target.checked)}
              className="rounded border-white/20 bg-white/10 text-blue-500 focus:ring-blue-500"
            />
            <label htmlFor="predicted" className="text-white/70 text-sm">
              Show Predicted Values
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="satellite"
              checked={showSatellite}
              onChange={(e) => setShowSatellite(e.target.checked)}
              className="rounded border-white/20 bg-white/10 text-blue-500 focus:ring-blue-500"
            />
            <label htmlFor="satellite" className="text-white/70 text-sm">
              Satellite Overlay
            </label>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => window.location.reload()}
            className="flex items-center space-x-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg text-white transition-colors"
          >
            <RefreshCw className="h-4 w-4" />
            <span>Refresh</span>
          </motion.button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Map Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="xl:col-span-3 bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 h-96"
        >
          <div className="relative w-full h-full bg-gradient-to-br from-blue-900/20 to-purple-900/20 rounded-lg overflow-hidden">
            {/* Simulated India Map Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-green-500/10 rounded-lg">
              <div className="absolute top-4 left-4 text-white/50 text-sm">India</div>
              
              {/* Simulated Geographic Features */}
              <div className="absolute top-1/4 left-1/3 w-32 h-24 bg-green-500/20 rounded-full blur-xl"></div>
              <div className="absolute top-1/2 right-1/4 w-40 h-16 bg-blue-500/20 rounded-full blur-xl"></div>
              <div className="absolute bottom-1/4 left-1/2 w-28 h-20 bg-yellow-500/20 rounded-full blur-xl"></div>
            </div>

            {/* Air Quality Markers */}
            {markers.map((marker) => (
              <motion.div
                key={marker.id}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                whileHover={{ scale: 1.2 }}
                className={`absolute w-6 h-6 rounded-full border-2 border-white cursor-pointer shadow-lg ${getMarkerColor(marker.pm25)}`}
                style={{
                  left: `${Math.random() * 80 + 10}%`,
                  top: `${Math.random() * 70 + 15}%`,
                }}
                onClick={() => setSelectedMarker(marker)}
              >
                <div className="absolute inset-0 rounded-full animate-ping opacity-75 bg-current"></div>
                {marker.predicted && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-400 rounded-full border border-white"></div>
                )}
              </motion.div>
            ))}

            {/* Selected Marker Info */}
            {selectedMarker && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute bottom-4 left-4 bg-white/10 backdrop-blur-lg rounded-lg p-4 border border-white/20 min-w-64"
              >
                <div className="flex items-center space-x-2 mb-2">
                  <MapPin className="h-4 w-4 text-white/70" />
                  <span className="text-white font-medium">{selectedMarker.location}</span>
                  {selectedMarker.predicted && (
                    <span className="text-xs bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded">
                      Predicted
                    </span>
                  )}
                </div>
                <div className="space-y-1">
                  <p className="text-white/70 text-sm">
                    PM2.5: <span className="text-white font-semibold">{selectedMarker.pm25.toFixed(0)} μg/m³</span>
                  </p>
                  <p className="text-white/70 text-sm">
                    AQI Level: <span className="text-white font-semibold">{getAQILevel(selectedMarker.pm25)}</span>
                  </p>
                </div>
              </motion.div>
            )}

            {/* Legend */}
            <div className="absolute top-4 right-4 bg-white/10 backdrop-blur-lg rounded-lg p-3 border border-white/20">
              <h4 className="text-white font-medium text-sm mb-2">Air Quality Index</h4>
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-white/70 text-xs">Good (0-30)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <span className="text-white/70 text-xs">Moderate (31-60)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                  <span className="text-white/70 text-xs">Poor (61-90)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="text-white/70 text-xs">Very Poor (91-120)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                  <span className="text-white/70 text-xs">Severe (121+)</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Controls Panel */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-4"
        >
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20">
            <h3 className="text-white font-medium mb-3 flex items-center space-x-2">
              <Layers className="h-4 w-4" />
              <span>Map Layers</span>
            </h3>
            <div className="space-y-2">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={showSatellite}
                  onChange={(e) => setShowSatellite(e.target.checked)}
                  className="rounded border-white/20 bg-white/10 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-white/70 text-sm">Satellite AOD</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={showPredicted}
                  onChange={(e) => setShowPredicted(e.target.checked)}
                  className="rounded border-white/20 bg-white/10 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-white/70 text-sm">ML Predictions</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  defaultChecked
                  className="rounded border-white/20 bg-white/10 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-white/70 text-sm">Ground Stations</span>
              </label>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20">
            <h3 className="text-white font-medium mb-3 flex items-center space-x-2">
              <Filter className="h-4 w-4" />
              <span>Filters</span>
            </h3>
            <div className="space-y-2">
              <select className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white text-sm">
                <option className="text-gray-900">All Pollutants</option>
                <option className="text-gray-900">PM2.5</option>
                <option className="text-gray-900">PM10</option>
                <option className="text-gray-900">NO2</option>
              </select>
              <select className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white text-sm">
                <option className="text-gray-900">All Regions</option>
                <option className="text-gray-900">Northern India</option>
                <option className="text-gray-900">Western India</option>
                <option className="text-gray-900">Southern India</option>
              </select>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20">
            <h3 className="text-white font-medium mb-3 flex items-center space-x-2">
              <Satellite className="h-4 w-4" />
              <span>Satellite Status</span>
            </h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-white/70 text-sm">INSAT-3D</span>
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-green-400 text-xs">Active</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/70 text-sm">INSAT-3DR</span>
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-green-400 text-xs">Active</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/70 text-sm">INSAT-3DS</span>
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                  <span className="text-yellow-400 text-xs">Standby</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};