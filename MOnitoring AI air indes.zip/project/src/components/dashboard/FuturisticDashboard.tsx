import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Satellite, 
  Activity, 
  Brain, 
  MapPin, 
  TrendingUp,
  Zap,
  Globe,
  Eye,
  Settings,
  Bell
} from 'lucide-react';
import { FuturisticBackground } from '../ui/FuturisticBackground';
import { GlassmorphicCard } from '../ui/GlassmorphicCard';
import { FloatingActionButton } from '../ui/FloatingActionButton';
import { HolographicDisplay } from '../ui/HolographicDisplay';
import { AnimatedCounter } from '../ui/AnimatedCounter';
import { useAuth } from '../auth/AuthProvider';

interface DashboardProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const FuturisticDashboard: React.FC<DashboardProps> = ({ activeTab, setActiveTab }) => {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [realTimeData, setRealTimeData] = useState({
    pm25: 156,
    aqi: 301,
    satellites: 3,
    accuracy: 87.3,
    coverage: 98.7
  });

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setIsLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Simulate real-time data updates
    const interval = setInterval(() => {
      setRealTimeData(prev => ({
        pm25: prev.pm25 + (Math.random() - 0.5) * 10,
        aqi: prev.aqi + (Math.random() - 0.5) * 20,
        satellites: 3,
        accuracy: prev.accuracy + (Math.random() - 0.5) * 2,
        coverage: prev.coverage + (Math.random() - 0.5) * 1
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const menuItems = [
    { id: 'overview', label: 'Neural Hub', icon: Brain, color: 'blue' },
    { id: 'map', label: 'Quantum Map', icon: Globe, color: 'purple' },
    { id: 'analytics', label: 'Data Matrix', icon: Activity, color: 'green' },
    { id: 'satellite', label: 'Orbital Feed', icon: Satellite, color: 'orange' },
    { id: 'ml', label: 'AI Core', icon: Brain, color: 'purple' },
    { id: 'spatial', label: 'Holo-Space', icon: Eye, color: 'cyan' }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <FuturisticBackground />
        <motion.div
          className="relative z-50 text-center"
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1 }}
        >
          <motion.div
            className="w-32 h-32 border-4 border-cyan-400/30 border-t-cyan-400 rounded-full mx-auto mb-8"
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          />
          <motion.h1
            className="text-4xl font-bold text-white mb-4 font-mono"
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            AIRSIGHT NEURAL NETWORK
          </motion.h1>
          <motion.p
            className="text-cyan-300 text-lg"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            Initializing quantum atmospheric analysis...
          </motion.p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      <FuturisticBackground />
      
      {/* Futuristic Header */}
      <motion.header
        className="relative z-40 backdrop-blur-xl bg-black/20 border-b border-cyan-400/30"
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <motion.div 
              className="flex items-center space-x-4"
              whileHover={{ scale: 1.05 }}
            >
              <div className="relative">
                <motion.div
                  className="w-12 h-12 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-lg flex items-center justify-center"
                  animate={{ 
                    boxShadow: [
                      '0 0 20px rgba(34, 211, 238, 0.5)',
                      '0 0 40px rgba(34, 211, 238, 0.8)',
                      '0 0 20px rgba(34, 211, 238, 0.5)'
                    ]
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Satellite className="h-6 w-6 text-white" />
                </motion.div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full animate-pulse" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white font-mono tracking-wider">
                  AIRSIGHT
                </h1>
                <p className="text-cyan-300 text-sm font-mono">
                  NEURAL ATMOSPHERIC MONITORING
                </p>
              </div>
            </motion.div>

            <div className="flex items-center space-x-6">
              {/* Real-time Status */}
              <HolographicDisplay className="px-4 py-2">
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    <span className="text-green-300 font-mono">ONLINE</span>
                  </div>
                  <div className="text-cyan-300 font-mono">
                    PM2.5: <AnimatedCounter value={realTimeData.pm25} decimals={0} suffix=" μg/m³" />
                  </div>
                  <div className="text-purple-300 font-mono">
                    AQI: <AnimatedCounter value={realTimeData.aqi} decimals={0} />
                  </div>
                </div>
              </HolographicDisplay>

              <FloatingActionButton
                icon={Bell}
                onClick={() => {}}
                size="sm"
                variant="warning"
              />

              <motion.div
                className="flex items-center space-x-3 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 border border-white/20"
                whileHover={{ scale: 1.05, backgroundColor: 'rgba(255,255,255,0.15)' }}
              >
                <div className="w-8 h-8 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-bold">
                    {user?.name?.charAt(0) || 'U'}
                  </span>
                </div>
                <span className="text-white font-mono">{user?.name}</span>
              </motion.div>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Navigation Sidebar */}
      <motion.nav
        className="fixed left-0 top-20 bottom-0 w-80 z-40 backdrop-blur-xl bg-black/20 border-r border-cyan-400/30"
        initial={{ x: -320, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.2 }}
      >
        <div className="p-6 space-y-4">
          <h2 className="text-cyan-300 font-mono text-lg tracking-wider mb-6">
            NEURAL MODULES
          </h2>
          
          {menuItems.map((item, index) => (
            <motion.button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-4 p-4 rounded-xl transition-all duration-300 group ${
                activeTab === item.id
                  ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-400/50'
                  : 'hover:bg-white/10 border border-transparent'
              }`}
              whileHover={{ scale: 1.02, x: 10 }}
              whileTap={{ scale: 0.98 }}
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <motion.div
                className={`p-2 rounded-lg bg-gradient-to-r ${
                  item.color === 'blue' ? 'from-blue-500 to-cyan-500' :
                  item.color === 'purple' ? 'from-purple-500 to-pink-500' :
                  item.color === 'green' ? 'from-green-500 to-emerald-500' :
                  item.color === 'orange' ? 'from-orange-500 to-red-500' :
                  'from-cyan-500 to-blue-500'
                }`}
                whileHover={{ rotateY: 180 }}
                transition={{ duration: 0.6 }}
                style={{ transformStyle: 'preserve-3d' }}
              >
                <item.icon className="h-5 w-5 text-white" />
              </motion.div>
              <div className="flex-1 text-left">
                <p className="text-white font-mono font-medium">{item.label}</p>
                <p className="text-white/60 text-xs font-mono">
                  {item.id === 'overview' && 'Central Command'}
                  {item.id === 'map' && 'Real-time Visualization'}
                  {item.id === 'analytics' && 'Data Processing'}
                  {item.id === 'satellite' && 'Orbital Data Stream'}
                  {item.id === 'ml' && 'Machine Learning'}
                  {item.id === 'spatial' && 'Holographic Mapping'}
                </p>
              </div>
              {activeTab === item.id && (
                <motion.div
                  className="w-2 h-8 bg-gradient-to-b from-cyan-400 to-blue-500 rounded-full"
                  layoutId="activeIndicator"
                />
              )}
            </motion.button>
          ))}
        </div>

        {/* System Status */}
        <div className="absolute bottom-6 left-6 right-6">
          <HolographicDisplay title="SYSTEM STATUS">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-cyan-300 font-mono text-sm">Neural Network</span>
                <span className="text-green-400 font-mono text-sm">OPTIMAL</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-cyan-300 font-mono text-sm">Satellite Link</span>
                <span className="text-green-400 font-mono text-sm">ACTIVE</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-cyan-300 font-mono text-sm">Data Flow</span>
                <span className="text-yellow-400 font-mono text-sm">HIGH</span>
              </div>
            </div>
          </HolographicDisplay>
        </div>
      </motion.nav>

      {/* Main Content Area */}
      <main className="ml-80 relative z-30 min-h-screen">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -50, scale: 0.95 }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="p-8"
          >
            {/* Overview Content */}
            {activeTab === 'overview' && (
              <div className="space-y-8">
                <motion.h1
                  className="text-4xl font-bold text-white font-mono tracking-wider"
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                >
                  NEURAL COMMAND CENTER
                </motion.h1>

                {/* Key Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
                  {[
                    { label: 'PM2.5 LEVEL', value: realTimeData.pm25, suffix: ' μg/m³', color: 'blue' },
                    { label: 'AQI INDEX', value: realTimeData.aqi, suffix: '', color: 'purple' },
                    { label: 'SATELLITES', value: realTimeData.satellites, suffix: ' ACTIVE', color: 'green' },
                    { label: 'ACCURACY', value: realTimeData.accuracy, suffix: '%', color: 'orange' }
                  ].map((metric, index) => (
                    <GlassmorphicCard key={metric.label} glowColor={metric.color}>
                      <div className="text-center">
                        <p className="text-white/70 font-mono text-sm mb-2">{metric.label}</p>
                        <p className="text-3xl font-bold text-white font-mono">
                          <AnimatedCounter 
                            value={metric.value} 
                            suffix={metric.suffix}
                            decimals={metric.label === 'ACCURACY' ? 1 : 0}
                          />
                        </p>
                        <motion.div
                          className={`w-full h-1 bg-gradient-to-r ${
                            metric.color === 'blue' ? 'from-blue-500 to-cyan-500' :
                            metric.color === 'purple' ? 'from-purple-500 to-pink-500' :
                            metric.color === 'green' ? 'from-green-500 to-emerald-500' :
                            'from-orange-500 to-red-500'
                          } rounded-full mt-4`}
                          initial={{ scaleX: 0 }}
                          animate={{ scaleX: 1 }}
                          transition={{ delay: index * 0.2, duration: 1 }}
                        />
                      </div>
                    </GlassmorphicCard>
                  ))}
                </div>

                {/* 3D Visualization Area */}
                <GlassmorphicCard className="h-96">
                  <div className="relative h-full flex items-center justify-center">
                    <motion.div
                      className="relative w-64 h-64"
                      animate={{ rotateY: 360 }}
                      transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                      style={{ transformStyle: 'preserve-3d' }}
                    >
                      {/* 3D Earth Representation */}
                      <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-500/30 to-green-500/30 border-2 border-cyan-400/50">
                        <div className="absolute inset-4 rounded-full bg-gradient-to-br from-blue-600/40 to-green-600/40">
                          <div className="absolute inset-4 rounded-full bg-gradient-to-br from-blue-700/50 to-green-700/50 flex items-center justify-center">
                            <Globe className="h-16 w-16 text-cyan-300" />
                          </div>
                        </div>
                      </div>
                      
                      {/* Orbiting Satellites */}
                      {[...Array(3)].map((_, i) => (
                        <motion.div
                          key={i}
                          className="absolute w-4 h-4 bg-yellow-400 rounded-full"
                          style={{
                            top: '50%',
                            left: '50%',
                            transformOrigin: '0 0',
                          }}
                          animate={{
                            rotate: 360,
                            x: Math.cos(i * 120 * Math.PI / 180) * 150,
                            y: Math.sin(i * 120 * Math.PI / 180) * 150,
                          }}
                          transition={{
                            duration: 10 + i * 2,
                            repeat: Infinity,
                            ease: "linear"
                          }}
                        />
                      ))}
                    </motion.div>

                    <div className="absolute bottom-4 left-4 right-4">
                      <HolographicDisplay title="GLOBAL MONITORING STATUS">
                        <div className="grid grid-cols-3 gap-4 text-center">
                          <div>
                            <p className="text-cyan-300 font-mono text-lg font-bold">
                              <AnimatedCounter value={realTimeData.coverage} decimals={1} suffix="%" />
                            </p>
                            <p className="text-white/70 font-mono text-xs">COVERAGE</p>
                          </div>
                          <div>
                            <p className="text-green-300 font-mono text-lg font-bold">
                              <AnimatedCounter value={1247} suffix="" />
                            </p>
                            <p className="text-white/70 font-mono text-xs">STATIONS</p>
                          </div>
                          <div>
                            <p className="text-purple-300 font-mono text-lg font-bold">
                              <AnimatedCounter value={98.7} decimals={1} suffix="%" />
                            </p>
                            <p className="text-white/70 font-mono text-xs">UPTIME</p>
                          </div>
                        </div>
                      </HolographicDisplay>
                    </div>
                  </div>
                </GlassmorphicCard>
              </div>
            )}

            {/* Placeholder for other tabs */}
            {activeTab !== 'overview' && (
              <div className="flex items-center justify-center h-96">
                <HolographicDisplay title={`${activeTab.toUpperCase()} MODULE`}>
                  <div className="text-center py-12">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    >
                      <Brain className="h-16 w-16 text-cyan-400 mx-auto mb-4" />
                    </motion.div>
                    <p className="text-cyan-300 font-mono text-lg">
                      NEURAL MODULE LOADING...
                    </p>
                    <p className="text-white/70 font-mono text-sm mt-2">
                      Advanced {activeTab} interface initializing
                    </p>
                  </div>
                </HolographicDisplay>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-8 right-8 z-50 space-y-4">
        <FloatingActionButton
          icon={Settings}
          onClick={() => setActiveTab('settings')}
          variant="secondary"
        />
        <FloatingActionButton
          icon={TrendingUp}
          onClick={() => setActiveTab('analytics')}
          variant="success"
        />
        <FloatingActionButton
          icon={Zap}
          onClick={() => {}}
          variant="warning"
        />
      </div>
    </div>
  );
};