import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Home, 
  MapPin, 
  BarChart3, 
  Satellite, 
  Brain, 
  Settings, 
  AlertTriangle,
  TrendingUp,
  Database,
  ChevronLeft,
  ChevronRight,
  Map,
  Grid
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const menuItems = [
  { id: 'overview', label: 'Overview', icon: Home },
  { id: 'map', label: 'Live Map', icon: MapPin },
  { id: 'spatial', label: 'Spatial Map', icon: Map },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'satellite', label: 'Satellite Data', icon: Satellite },
  { id: 'ml', label: 'ML Models', icon: Brain },
  { id: 'alerts', label: 'Alerts', icon: AlertTriangle },
  { id: 'trends', label: 'Trends', icon: TrendingUp },
  { id: 'data', label: 'Data Sources', icon: Database },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <motion.div
      initial={{ x: -300 }}
      animate={{ x: 0 }}
      className={`bg-white/10 backdrop-blur-lg border-r border-white/20 transition-all duration-300 ${
        isCollapsed ? 'w-16' : 'w-64'
      }`}
    >
      <div className="p-4">
        <div className="flex items-center justify-between mb-8">
          {!isCollapsed && (
            <h2 className="text-lg font-semibold text-white">Navigation</h2>
          )}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1 text-white/70 hover:text-white transition-colors"
          >
            {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </button>
        </div>

        <nav className="space-y-2">
          {menuItems.map((item) => (
            <motion.button
              key={item.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-all duration-200 ${
                activeTab === item.id
                  ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              <item.icon className="h-5 w-5 flex-shrink-0" />
              {!isCollapsed && <span className="text-sm font-medium">{item.label}</span>}
            </motion.button>
          ))}
        </nav>
      </div>
    </motion.div>
  );
};