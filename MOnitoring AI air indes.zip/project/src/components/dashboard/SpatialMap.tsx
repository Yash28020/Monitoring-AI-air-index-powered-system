import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Map, 
  Layers, 
  Download, 
  RefreshCw, 
  ZoomIn, 
  ZoomOut,
  MapPin,
  Satellite,
  Filter,
  Grid,
  Eye,
  BarChart3
} from 'lucide-react';
import { apiService } from '../../services/api';

interface SpatialData {
  lat: number;
  lng: number;
  pm25_predicted: number;
  pm25_actual?: number;
  aod: number;
  confidence: number;
  region: string;
}

export const SpatialMap: React.FC = () => {
  const [spatialData, setSpatialData] = useState<SpatialData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedLayer, setSelectedLayer] = useState<'pm25' | 'aod' | 'confidence'>('pm25');
  const [showPredicted, setShowPredicted] = useState(true);
  const [showActual, setShowActual] = useState(true);
  const [zoomLevel, setZoomLevel] = useState(1);

  useEffect(() => {
    const generateSpatialData = () => {
      const data: SpatialData[] = [];
      
      // Generate grid points across India
      for (let lat = 8; lat <= 37; lat += 0.5) {
        for (let lng = 68; lng <= 97; lng += 0.5) {
          // Simulate higher pollution in northern regions
          const northernFactor = lat > 25 ? 1.5 : 1.0;
          const urbanFactor = Math.random() > 0.7 ? 1.3 : 1.0;
          
          const aod = Math.random() * 0.8 * northernFactor;
          const pm25_predicted = aod * 180 + Math.random() * 30;
          const pm25_actual = Math.random() > 0.8 ? pm25_predicted + (Math.random() - 0.5) * 20 : undefined;
          
          data.push({
            lat,
            lng,
            pm25_predicted: pm25_predicted * urbanFactor,
            pm25_actual,
            aod,
            confidence: 0.7 + Math.random() * 0.3,
            region: lat > 28 ? 'Northern' : lat > 20 ? 'Central' : 'Southern'
          });
        }
      }
      
      setSpatialData(data);
      setIsLoading(false);
    };

    generateSpatialData();
  }, []);

  const getColorForValue = (value: number, type: 'pm25' | 'aod' | 'confidence') => {
    switch (type) {
      case 'pm25':
        if (value <= 30) return '#10B981'; // Green
        if (value <= 60) return '#F59E0B'; // Yellow
        if (value <= 90) return '#F97316'; // Orange
        if (value <= 120) return '#EF4444'; // Red
        return '#8B5CF6'; // Purple
      case 'aod':
        const intensity = Math.min(value / 0.8, 1);
        return `rgba(239, 68, 68, ${intensity})`;
      case 'confidence':
        const conf = Math.min(value, 1);
        return `rgba(16, 185, 129, ${conf})`;
      default:
        return '#6B7280';
    }
  };

  const getValueForLayer = (data: SpatialData) => {
    switch (selectedLayer) {
      case 'pm25': return data.pm25_predicted;
      case 'aod': return data.aod;
      case 'confidence': return data.confidence;
      default: return data.pm25_predicted;
    }
  };

  const getLayerLabel = () => {
    switch (selectedLayer) {
      case 'pm25': return 'PM2.5 Concentration (μg/m³)';
      case 'aod': return 'Aerosol Optical Depth';
      case 'confidence': return 'Prediction Confidence';
      default: return 'PM2.5 Concentration';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">High-Resolution Spatial Map</h2>
        <div className="flex items-center space-x-4">
          <select 
            value={selectedLayer}
            onChange={(e) => setSelectedLayer(e.target.value as 'pm25' | 'aod' | 'confidence')}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white text-sm"
          >
            <option value="pm25" className="text-gray-900">PM2.5 Concentration</option>
            <option value="aod" className="text-gray-900">AOD Values</option>
            <option value="confidence" className="text-gray-900">Prediction Confidence</option>
          </select>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-lg text-white transition-colors"
          >
            <Download className="h-4 w-4" />
            <span>Export Map</span>
          </motion.button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Main Map */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="xl:col-span-3 bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white flex items-center space-x-2">
              <Map className="h-5 w-5" />
              <span>{getLayerLabel()}</span>
            </h3>
            <div className="flex items-center space-x-2">
              <button 
                onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.1))}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-colors"
              >
                <ZoomOut className="h-4 w-4" />
              </button>
              <span className="text-white/70 text-sm">{(zoomLevel * 100).toFixed(0)}%</span>
              <button 
                onClick={() => setZoomLevel(Math.min(2, zoomLevel + 0.1))}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-colors"
              >
                <ZoomIn className="h-4 w-4" />
              </button>
            </div>
          </div>
          
          <div 
            className="relative w-full h-96 bg-gradient-to-br from-blue-900/20 to-purple-900/20 rounded-lg overflow-hidden"
            style={{ transform: `scale(${zoomLevel})` }}
          >
            {/* India outline */}
            <div className="absolute inset-0 opacity-30">
              <svg viewBox="0 0 400 300" className="w-full h-full">
                <path
                  d="M100 50 L300 50 L320 80 L310 120 L290 150 L280 180 L260 200 L240 220 L200 240 L160 230 L120 210 L100 180 L90 150 L85 120 L90 90 Z"
                  fill="none"
                  stroke="rgba(255,255,255,0.3)"
                  strokeWidth="2"
                />
              </svg>
            </div>

            {/* Spatial data points */}
            {spatialData.filter((_, index) => index % 3 === 0).map((point, index) => {
              const value = getValueForLayer(point);
              const color = getColorForValue(value, selectedLayer);
              const x = ((point.lng - 68) / (97 - 68)) * 100;
              const y = ((37 - point.lat) / (37 - 8)) * 100;
              
              return (
                <div
                  key={index}
                  className="absolute w-2 h-2 rounded-full opacity-70 hover:opacity-100 transition-opacity cursor-pointer"
                  style={{
                    left: `${x}%`,
                    top: `${y}%`,
                    backgroundColor: color,
                    boxShadow: `0 0 10px ${color}`,
                  }}
                  title={`${point.region}: ${value.toFixed(selectedLayer === 'aod' ? 3 : 0)}${selectedLayer === 'pm25' ? ' μg/m³' : ''}`}
                />
              );
            })}

            {/* Major cities */}
            <div className="absolute top-1/4 left-1/3 w-3 h-3 bg-white rounded-full border-2 border-red-500">
              <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-white text-xs whitespace-nowrap">
                Delhi
              </div>
            </div>
            <div className="absolute top-1/2 left-1/4 w-3 h-3 bg-white rounded-full border-2 border-orange-500">
              <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-white text-xs whitespace-nowrap">
                Mumbai
              </div>
            </div>
            <div className="absolute bottom-1/3 right-1/3 w-3 h-3 bg-white rounded-full border-2 border-yellow-500">
              <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-white text-xs whitespace-nowrap">
                Bangalore
              </div>
            </div>
          </div>

          {/* Color Scale Legend */}
          <div className="mt-4 flex items-center justify-center">
            <div className="bg-white/10 backdrop-blur-lg rounded-lg p-3 border border-white/20">
              <div className="flex items-center space-x-4">
                <span className="text-white/70 text-sm">Low</span>
                <div className="flex space-x-1">
                  {selectedLayer === 'pm25' ? (
                    <>
                      <div className="w-4 h-4 bg-green-500 rounded"></div>
                      <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                      <div className="w-4 h-4 bg-orange-500 rounded"></div>
                      <div className="w-4 h-4 bg-red-500 rounded"></div>
                      <div className="w-4 h-4 bg-purple-500 rounded"></div>
                    </>
                  ) : (
                    Array.from({ length: 5 }, (_, i) => (
                      <div 
                        key={i}
                        className="w-4 h-4 rounded"
                        style={{ 
                          backgroundColor: getColorForValue((i + 1) * 0.2, selectedLayer)
                        }}
                      ></div>
                    ))
                  )}
                </div>
                <span className="text-white/70 text-sm">High</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Controls and Statistics */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-4"
        >
          {/* Layer Controls */}
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20">
            <h3 className="text-white font-medium mb-3 flex items-center space-x-2">
              <Layers className="h-4 w-4" />
              <span>Map Layers</span>
            </h3>
            <div className="space-y-2">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={showPredicted}
                  onChange={(e) => setShowPredicted(e.target.checked)}
                  className="rounded border-white/20 bg-white/10 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-white/70 text-sm">ML Predictions</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={showActual}
                  onChange={(e) => setShowActual(e.target.checked)}
                  className="rounded border-white/20 bg-white/10 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-white/70 text-sm">Ground Truth</span>
              </label>
            </div>
          </div>

          {/* Statistics */}
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20">
            <h3 className="text-white font-medium mb-3 flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>Statistics</span>
            </h3>
            <div className="space-y-3">
              <div>
                <p className="text-white/70 text-sm">Coverage Area</p>
                <p className="text-white font-semibold">3.28M km²</p>
              </div>
              <div>
                <p className="text-white/70 text-sm">Data Points</p>
                <p className="text-white font-semibold">{spatialData.length.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-white/70 text-sm">Avg PM2.5</p>
                <p className="text-white font-semibold">
                  {(spatialData.reduce((sum, d) => sum + d.pm25_predicted, 0) / spatialData.length).toFixed(0)} μg/m³
                </p>
              </div>
              <div>
                <p className="text-white/70 text-sm">Avg Confidence</p>
                <p className="text-white font-semibold">
                  {(spatialData.reduce((sum, d) => sum + d.confidence, 0) / spatialData.length * 100).toFixed(0)}%
                </p>
              </div>
            </div>
          </div>

          {/* Regional Summary */}
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20">
            <h3 className="text-white font-medium mb-3 flex items-center space-x-2">
              <MapPin className="h-4 w-4" />
              <span>Regional Summary</span>
            </h3>
            <div className="space-y-2">
              {['Northern', 'Central', 'Southern'].map(region => {
                const regionData = spatialData.filter(d => d.region === region);
                const avgPM25 = regionData.reduce((sum, d) => sum + d.pm25_predicted, 0) / regionData.length;
                
                return (
                  <div key={region} className="flex justify-between items-center">
                    <span className="text-white/70 text-sm">{region}</span>
                    <span className={`text-sm font-semibold ${
                      avgPM25 > 100 ? 'text-red-400' : 
                      avgPM25 > 60 ? 'text-orange-400' : 'text-green-400'
                    }`}>
                      {avgPM25.toFixed(0)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};