import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { DashboardHeader } from './DashboardHeader';
import { Sidebar } from './Sidebar';
import { Overview } from './Overview';
import { LiveMap } from './LiveMap';
import { Analytics } from './Analytics';
import { SatelliteDataComponent } from './SatelliteData';
import { MLModels } from './MLModels';
import { SpatialMap } from './SpatialMap';
import { Settings } from './Settings';
import { Alerts } from './Alerts';
import { Trends } from './Trends';
import { DataSources } from './DataSources';
import { FuturisticDashboard } from './FuturisticDashboard';

export const Dashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [useFuturisticMode, setUseFuturisticMode] = useState(true);

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <Overview />;
      case 'map':
        return <LiveMap />;
      case 'analytics':
        return <Analytics />;
      case 'satellite':
        return <SatelliteDataComponent />;
      case 'ml':
        return <MLModels />;
      case 'spatial':
        return <SpatialMap />;
      case 'alerts':
        return <Alerts />;
      case 'trends':
        return <Trends />;
      case 'data':
        return <DataSources />;
      case 'settings':
        return <Settings />;
      default:
        return <Overview />;
    }
  };

  // Use futuristic mode by default for demo impact
  if (useFuturisticMode) {
    return <FuturisticDashboard activeTab={activeTab} setActiveTab={setActiveTab} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 flex flex-col">
      <DashboardHeader />
      <div className="flex flex-1">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
        <main className="flex-1 overflow-auto">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {renderContent()}
          </motion.div>
        </main>
      </div>
    </div>
  );
};