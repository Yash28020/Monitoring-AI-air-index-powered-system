import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter
} from 'recharts';
import { TrendingUp, BarChart3, PieChart as PieChartIcon, Activity } from 'lucide-react';

const timeSeriesData = [
  { time: '00:00', pm25: 45, pm10: 78, aod: 0.32 },
  { time: '04:00', pm25: 52, pm10: 89, aod: 0.41 },
  { time: '08:00', pm25: 78, pm10: 123, aod: 0.56 },
  { time: '12:00', pm25: 95, pm10: 145, aod: 0.67 },
  { time: '16:00', pm25: 112, pm10: 167, aod: 0.73 },
  { time: '20:00', pm25: 89, pm10: 134, aod: 0.61 },
];

const cityData = [
  { city: 'Delhi', pm25: 156, pm10: 234, aqi: 301 },
  { city: 'Mumbai', pm25: 89, pm10: 134, aqi: 156 },
  { city: 'Bangalore', pm25: 67, pm10: 98, aqi: 98 },
  { city: 'Chennai', pm25: 78, pm10: 112, aqi: 123 },
  { city: 'Kolkata', pm25: 134, pm10: 189, aqi: 267 },
  { city: 'Hyderabad', pm25: 72, pm10: 105, aqi: 108 },
];

const aqiDistribution = [
  { name: 'Good', value: 12, color: '#10B981' },
  { name: 'Moderate', value: 25, color: '#F59E0B' },
  { name: 'Poor', value: 35, color: '#F97316' },
  { name: 'Very Poor', value: 20, color: '#EF4444' },
  { name: 'Severe', value: 8, color: '#8B5CF6' },
];

const correlationData = [
  { aod: 0.2, pm25: 35 },
  { aod: 0.3, pm25: 48 },
  { aod: 0.4, pm25: 62 },
  { aod: 0.5, pm25: 78 },
  { aod: 0.6, pm25: 95 },
  { aod: 0.7, pm25: 112 },
  { aod: 0.8, pm25: 135 },
];

export const Analytics: React.FC = () => {
  const [selectedMetric, setSelectedMetric] = useState('pm25');
  const [timeRange, setTimeRange] = useState('24h');

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Analytics Dashboard</h2>
        <div className="flex items-center space-x-4">
          <select 
            value={selectedMetric}
            onChange={(e) => setSelectedMetric(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white text-sm"
          >
            <option value="pm25" className="text-gray-900">PM2.5</option>
            <option value="pm10" className="text-gray-900">PM10</option>
            <option value="aod" className="text-gray-900">AOD</option>
          </select>
          <select 
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white text-sm"
          >
            <option value="24h" className="text-gray-900">Last 24 Hours</option>
            <option value="7d" className="text-gray-900">Last 7 Days</option>
            <option value="30d" className="text-gray-900">Last 30 Days</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Time Series Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <div className="flex items-center space-x-2 mb-4">
            <TrendingUp className="h-5 w-5 text-white/70" />
            <h3 className="text-lg font-semibold text-white">Pollutant Trends</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={timeSeriesData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
              <XAxis dataKey="time" stroke="#ffffff70" />
              <YAxis stroke="#ffffff70" />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#ffffff'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="pm25" 
                stroke="#3B82F6" 
                strokeWidth={2}
                name="PM2.5 (μg/m³)"
              />
              <Line 
                type="monotone" 
                dataKey="pm10" 
                stroke="#10B981" 
                strokeWidth={2}
                name="PM10 (μg/m³)"
              />
              <Line 
                type="monotone" 
                dataKey="aod" 
                stroke="#F59E0B" 
                strokeWidth={2}
                name="AOD"
                yAxisId="right"
              />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* City Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <div className="flex items-center space-x-2 mb-4">
            <BarChart3 className="h-5 w-5 text-white/70" />
            <h3 className="text-lg font-semibold text-white">City Comparison</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={cityData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
              <XAxis dataKey="city" stroke="#ffffff70" />
              <YAxis stroke="#ffffff70" />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#ffffff'
                }}
              />
              <Legend />
              <Bar dataKey="pm25" fill="#3B82F6" name="PM2.5 (μg/m³)" />
              <Bar dataKey="pm10" fill="#10B981" name="PM10 (μg/m³)" />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* AQI Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <div className="flex items-center space-x-2 mb-4">
            <PieChartIcon className="h-5 w-5 text-white/70" />
            <h3 className="text-lg font-semibold text-white">AQI Distribution</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={aqiDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {aqiDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#ffffff'
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>

        {/* AOD vs PM2.5 Correlation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
        >
          <div className="flex items-center space-x-2 mb-4">
            <Activity className="h-5 w-5 text-white/70" />
            <h3 className="text-lg font-semibold text-white">AOD vs PM2.5 Correlation</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <ScatterChart data={correlationData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
              <XAxis 
                type="number" 
                dataKey="aod" 
                name="AOD" 
                stroke="#ffffff70"
                domain={[0, 1]}
              />
              <YAxis 
                type="number" 
                dataKey="pm25" 
                name="PM2.5" 
                stroke="#ffffff70"
                domain={[0, 150]}
              />
              <Tooltip 
                cursor={{ strokeDasharray: '3 3' }}
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#ffffff'
                }}
              />
              <Scatter dataKey="pm25" fill="#8B5CF6" />
            </ScatterChart>
          </ResponsiveContainer>
          <div className="mt-4 p-3 bg-white/5 rounded-lg">
            <p className="text-white/70 text-sm">
              <strong>R² = 0.89</strong> - Strong positive correlation between AOD and PM2.5 levels
            </p>
          </div>
        </motion.div>
      </div>

      {/* Summary Statistics */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Statistical Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <p className="text-2xl font-bold text-white">87.3</p>
            <p className="text-white/70 text-sm">Average PM2.5 (μg/m³)</p>
            <p className="text-green-400 text-sm">↓ 12% from last week</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-white">0.58</p>
            <p className="text-white/70 text-sm">Average AOD</p>
            <p className="text-red-400 text-sm">↑ 8% from last week</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-white">156</p>
            <p className="text-white/70 text-sm">Average AQI</p>
            <p className="text-orange-400 text-sm">↑ 3% from last week</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};