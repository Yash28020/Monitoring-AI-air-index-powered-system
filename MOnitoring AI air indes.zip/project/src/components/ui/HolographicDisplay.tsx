import React from 'react';
import { motion } from 'framer-motion';

interface HolographicDisplayProps {
  children: React.ReactNode;
  title?: string;
  className?: string;
}

export const HolographicDisplay: React.FC<HolographicDisplayProps> = ({
  children,
  title,
  className = ''
}) => {
  return (
    <motion.div
      className={`relative ${className}`}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      {/* Holographic Frame */}
      <div className="relative backdrop-blur-2xl bg-gradient-to-br from-cyan-500/10 via-blue-500/5 to-purple-500/10 rounded-3xl border border-cyan-400/30 shadow-2xl overflow-hidden">
        
        {/* Scanning Lines */}
        <div className="absolute inset-0 pointer-events-none">
          <motion.div
            className="absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent"
            animate={{ y: [0, 400, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          />
        </div>

        {/* Corner Brackets */}
        {[...Array(4)].map((_, i) => (
          <div
            key={i}
            className={`absolute w-8 h-8 border-cyan-400/60 ${
              i === 0 ? 'top-4 left-4 border-t-2 border-l-2' :
              i === 1 ? 'top-4 right-4 border-t-2 border-r-2' :
              i === 2 ? 'bottom-4 left-4 border-b-2 border-l-2' :
              'bottom-4 right-4 border-b-2 border-r-2'
            }`}
          />
        ))}

        {/* Title Bar */}
        {title && (
          <div className="relative z-10 px-6 py-3 border-b border-cyan-400/20">
            <motion.h3 
              className="text-cyan-300 font-mono text-sm tracking-wider"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              {title}
            </motion.h3>
          </div>
        )}

        {/* Content */}
        <div className="relative z-10 p-6">
          {children}
        </div>

        {/* Glitch Effect */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 mix-blend-overlay"
          animate={{ 
            opacity: [0, 0.1, 0],
            x: [0, 2, -2, 0]
          }}
          transition={{ 
            duration: 0.1,
            repeat: Infinity,
            repeatDelay: 5
          }}
        />
      </div>

      {/* Floating Data Points */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-cyan-400/60 rounded-full"
            style={{
              left: `${10 + i * 15}%`,
              top: `${20 + (i % 3) * 30}%`,
            }}
            animate={{
              scale: [1, 1.5, 1],
              opacity: [0.6, 1, 0.6],
            }}
            transition={{
              duration: 2 + i * 0.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>
    </motion.div>
  );
};