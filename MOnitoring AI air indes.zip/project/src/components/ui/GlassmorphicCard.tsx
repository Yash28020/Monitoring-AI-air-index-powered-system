import React from 'react';
import { motion } from 'framer-motion';

interface GlassmorphicCardProps {
  children: React.ReactNode;
  className?: string;
  hover3D?: boolean;
  glowColor?: string;
}

export const GlassmorphicCard: React.FC<GlassmorphicCardProps> = ({ 
  children, 
  className = '', 
  hover3D = true,
  glowColor = 'blue'
}) => {
  return (
    <motion.div
      className={`
        relative backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl
        shadow-2xl overflow-hidden group cursor-pointer
        ${className}
      `}
      whileHover={hover3D ? { 
        scale: 1.02,
        rotateX: 5,
        rotateY: 5,
        z: 50,
      } : {}}
      transition={{ 
        type: "spring", 
        stiffness: 300, 
        damping: 20 
      }}
      style={{
        transformStyle: 'preserve-3d',
        perspective: '1000px',
      }}
    >
      {/* Animated Border Gradient */}
      <div className="absolute inset-0 rounded-2xl p-[1px] bg-gradient-to-r from-blue-500/50 via-purple-500/50 to-cyan-500/50 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
        <div className="w-full h-full bg-black/20 rounded-2xl" />
      </div>

      {/* Glow Effect */}
      <div 
        className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-30 transition-opacity duration-500 blur-xl bg-gradient-to-r ${
          glowColor === 'blue' ? 'from-blue-500 to-cyan-500' :
          glowColor === 'purple' ? 'from-purple-500 to-pink-500' :
          glowColor === 'green' ? 'from-green-500 to-emerald-500' :
          'from-orange-500 to-red-500'
        }`}
      />

      {/* Shimmer Effect */}
      <div className="absolute inset-0 rounded-2xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" />
      </div>

      {/* Content */}
      <div className="relative z-10 p-6">
        {children}
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white/30 rounded-full"
            style={{
              left: `${20 + i * 30}%`,
              top: `${20 + i * 20}%`,
            }}
            animate={{
              y: [-10, 10, -10],
              opacity: [0.3, 0.8, 0.3],
            }}
            transition={{
              duration: 3 + i,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>
    </motion.div>
  );
};