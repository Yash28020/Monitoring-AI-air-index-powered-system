import React from 'react';
import { motion } from 'framer-motion';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface FloatingActionButtonProps {
  icon: LucideIcon;
  onClick: () => void;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger';
}

export const FloatingActionButton: React.FC<FloatingActionButtonProps> = ({
  icon: Icon,
  onClick,
  className = '',
  size = 'md',
  variant = 'primary'
}) => {
  const sizeClasses = {
    sm: 'w-12 h-12',
    md: 'w-16 h-16',
    lg: 'w-20 h-20'
  };

  const iconSizes = {
    sm: 'h-5 w-5',
    md: 'h-6 w-6',
    lg: 'h-8 w-8'
  };

  const variants = {
    primary: 'from-blue-500 to-purple-600 shadow-blue-500/25',
    secondary: 'from-gray-500 to-gray-600 shadow-gray-500/25',
    success: 'from-green-500 to-emerald-600 shadow-green-500/25',
    warning: 'from-yellow-500 to-orange-600 shadow-yellow-500/25',
    danger: 'from-red-500 to-pink-600 shadow-red-500/25'
  };

  return (
    <motion.button
      onClick={onClick}
      className={`
        ${sizeClasses[size]} rounded-full bg-gradient-to-r ${variants[variant]}
        shadow-2xl backdrop-blur-sm border border-white/20
        flex items-center justify-center text-white
        relative overflow-hidden group
        ${className}
      `}
      whileHover={{ 
        scale: 1.1,
        rotateZ: 5,
        boxShadow: '0 20px 40px rgba(0,0,0,0.3)'
      }}
      whileTap={{ scale: 0.95 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      {/* Ripple Effect */}
      <motion.div
        className="absolute inset-0 rounded-full bg-white/20"
        initial={{ scale: 0, opacity: 0 }}
        whileHover={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
      />

      {/* Rotating Border */}
      <div className="absolute inset-0 rounded-full border-2 border-transparent bg-gradient-to-r from-white/30 via-transparent to-white/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-spin" />

      {/* Icon */}
      <motion.div
        whileHover={{ rotateY: 180 }}
        transition={{ duration: 0.6 }}
        style={{ transformStyle: 'preserve-3d' }}
      >
        <Icon className={iconSizes[size]} />
      </motion.div>

      {/* Pulse Effect */}
      <div className="absolute inset-0 rounded-full bg-gradient-to-r from-white/10 to-white/5 animate-pulse" />
    </motion.button>
  );
};