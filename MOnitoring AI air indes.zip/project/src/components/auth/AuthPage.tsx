import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Satellite, Wind, Eye, BarChart3 } from 'lucide-react';
import { LoginForm } from './LoginForm';
import { SignupForm } from './SignupForm';

export const AuthPage: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);

  const features = [
    {
      icon: <Satellite className="h-8 w-8 text-blue-400" />,
      title: "Satellite Monitoring",
      description: "Real-time AOD data from INSAT-3D/3DR/3DS satellites"
    },
    {
      icon: <Wind className="h-8 w-8 text-green-400" />,
      title: "AI-Powered Predictions",
      description: "Machine learning models for accurate PM concentration forecasting"
    },
    {
      icon: <Eye className="h-8 w-8 text-purple-400" />,
      title: "Live Monitoring",
      description: "Ground-based CPCB station data integration"
    },
    {
      icon: <BarChart3 className="h-8 w-8 text-orange-400" />,
      title: "Advanced Analytics",
      description: "Comprehensive data visualization and trend analysis"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 flex">
      {/* Left Panel - Features */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-center p-12">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-md"
        >
          <div className="flex items-center space-x-3 mb-8">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
              <Satellite className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-white">AirSight</h1>
          </div>
          
          <p className="text-xl text-white/80 mb-12">
            Advanced air pollution monitoring platform using satellite observations, 
            ground-based measurements, and AI/ML techniques.
          </p>

          <div className="space-y-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="flex items-start space-x-4"
              >
                <div className="flex-shrink-0 p-2 bg-white/10 rounded-lg">
                  {feature.icon}
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white mb-1">
                    {feature.title}
                  </h3>
                  <p className="text-white/70 text-sm">
                    {feature.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Right Panel - Auth Forms */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden text-center mb-8">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                <Satellite className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-white">AirSight</h1>
            </div>
            <p className="text-white/70">
              Advanced air pollution monitoring platform
            </p>
          </div>

          {/* Auth Form Toggle */}
          <div className="flex mb-8">
            <button
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-2 px-4 text-center rounded-l-lg transition-colors ${
                isLogin
                  ? 'bg-white/20 text-white border-b-2 border-blue-400'
                  : 'bg-white/5 text-white/70 hover:bg-white/10'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-2 px-4 text-center rounded-r-lg transition-colors ${
                !isLogin
                  ? 'bg-white/20 text-white border-b-2 border-blue-400'
                  : 'bg-white/5 text-white/70 hover:bg-white/10'
              }`}
            >
              Sign Up
            </button>
          </div>

          {/* Forms */}
          <motion.div
            key={isLogin ? 'login' : 'signup'}
            initial={{ opacity: 0, x: isLogin ? -20 : 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            {isLogin ? <LoginForm /> : <SignupForm />}
          </motion.div>
        </div>
      </div>
    </div>
  );
};