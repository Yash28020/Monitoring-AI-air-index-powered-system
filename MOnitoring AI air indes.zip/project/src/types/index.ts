export interface User {
  id: string;
  email: string;
  name: string;
  role: 'researcher' | 'scientist' | 'analyst';
  organization: string;
  created_at: string;
}

export interface AirQualityData {
  id: string;
  location: {
    lat: number;
    lng: number;
    name: string;
    state: string;
  };
  pm25: number;
  pm10: number;
  aod: number;
  timestamp: string;
  predicted: boolean;
  confidence: number;
  weather: {
    temperature: number;
    humidity: number;
    windSpeed: number;
    windDirection: number;
  };
}

export interface SatelliteData {
  id: string;
  satellite: 'INSAT-3D' | 'INSAT-3DR' | 'INSAT-3DS';
  aod_value: number;
  coordinates: [number, number];
  timestamp: string;
  cloud_cover: number;
  quality_flag: 'good' | 'moderate' | 'poor';
}

export interface CPCBStation {
  id: string;
  name: string;
  location: {
    lat: number;
    lng: number;
    city: string;
    state: string;
  };
  pollutants: {
    pm25: number;
    pm10: number;
    no2: number;
    so2: number;
    co: number;
    o3: number;
  };
  aqi: number;
  status: 'online' | 'offline' | 'maintenance';
  last_updated: string;
}

export interface PredictionModel {
  id: string;
  name: string;
  algorithm: 'random_forest' | 'neural_network' | 'svm' | 'gradient_boosting';
  accuracy: number;
  mae: number;
  rmse: number;
  last_trained: string;
  features: string[];
}

export interface Alert {
  id: string;
  type: 'pm_threshold' | 'aqi_severe' | 'satellite_anomaly' | 'model_drift';
  location: string;
  message: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: string;
  acknowledged: boolean;
}

export interface SpatialMapData {
  id: string;
  region: string;
  resolution: string;
  pm25_grid: number[][];
  aod_grid: number[][];
  confidence_grid: number[][];
  bounds: {
    north: number;
    south: number;
    east: number;
    west: number;
  };
  generated_at: string;
}

export interface AtmosphericData {
  id: string;
  source: 'MERRA-2' | 'ERA5' | 'NCEP';
  location: {
    lat: number;
    lng: number;
  };
  variables: {
    temperature: number;
    humidity: number;
    pressure: number;
    wind_speed: number;
    wind_direction: number;
    boundary_layer_height: number;
    solar_radiation: number;
  };
  timestamp: string;
}

export interface ValidationResult {
  id: string;
  model_id: string;
  predicted_value: number;
  actual_value: number;
  residual: number;
  location: {
    lat: number;
    lng: number;
    name: string;
  };
  timestamp: string;
}