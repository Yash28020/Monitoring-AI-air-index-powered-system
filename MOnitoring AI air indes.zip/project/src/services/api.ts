import { AirQualityData, SatelliteData, CPCBStation, PredictionModel } from '../types';

// Enhanced mock data for comprehensive demonstration
const mockAirQualityData: AirQualityData[] = [
  {
    id: '1',
    location: { lat: 28.6139, lng: 77.2090, name: 'Delhi', state: 'Delhi' },
    pm25: 156,
    pm10: 234,
    aod: 0.65,
    timestamp: new Date().toISOString(),
    predicted: true,
    confidence: 0.87,
    weather: { temperature: 32, humidity: 65, windSpeed: 8, windDirection: 180 }
  },
  {
    id: '2',
    location: { lat: 19.0760, lng: 72.8777, name: 'Mumbai', state: 'Maharashtra' },
    pm25: 89,
    pm10: 134,
    aod: 0.45,
    timestamp: new Date().toISOString(),
    predicted: true,
    confidence: 0.92,
    weather: { temperature: 29, humidity: 78, windSpeed: 12, windDirection: 220 }
  },
  {
    id: '3',
    location: { lat: 12.9716, lng: 77.5946, name: 'Bangalore', state: 'Karnataka' },
    pm25: 67,
    pm10: 98,
    aod: 0.32,
    timestamp: new Date().toISOString(),
    predicted: false,
    confidence: 0.95,
    weather: { temperature: 26, humidity: 68, windSpeed: 6, windDirection: 145 }
  },
  {
    id: '4',
    location: { lat: 13.0827, lng: 80.2707, name: 'Chennai', state: 'Tamil Nadu' },
    pm25: 78,
    pm10: 112,
    aod: 0.38,
    timestamp: new Date().toISOString(),
    predicted: true,
    confidence: 0.89,
    weather: { temperature: 31, humidity: 82, windSpeed: 10, windDirection: 200 }
  },
  {
    id: '5',
    location: { lat: 22.5726, lng: 88.3639, name: 'Kolkata', state: 'West Bengal' },
    pm25: 134,
    pm10: 189,
    aod: 0.58,
    timestamp: new Date().toISOString(),
    predicted: true,
    confidence: 0.84,
    weather: { temperature: 30, humidity: 75, windSpeed: 7, windDirection: 160 }
  },
  {
    id: '6',
    location: { lat: 17.3850, lng: 78.4867, name: 'Hyderabad', state: 'Telangana' },
    pm25: 72,
    pm10: 105,
    aod: 0.35,
    timestamp: new Date().toISOString(),
    predicted: false,
    confidence: 0.91,
    weather: { temperature: 28, humidity: 62, windSpeed: 9, windDirection: 175 }
  }
];

const mockSatelliteData: SatelliteData[] = [
  {
    id: '1',
    satellite: 'INSAT-3D',
    aod_value: 0.65,
    coordinates: [28.6139, 77.2090],
    timestamp: new Date().toISOString(),
    cloud_cover: 15,
    quality_flag: 'good'
  },
  {
    id: '2',
    satellite: 'INSAT-3DR',
    aod_value: 0.45,
    coordinates: [19.0760, 72.8777],
    timestamp: new Date().toISOString(),
    cloud_cover: 25,
    quality_flag: 'good'
  },
  {
    id: '3',
    satellite: 'INSAT-3D',
    aod_value: 0.32,
    coordinates: [12.9716, 77.5946],
    timestamp: new Date().toISOString(),
    cloud_cover: 10,
    quality_flag: 'good'
  },
  {
    id: '4',
    satellite: 'INSAT-3DS',
    aod_value: 0.58,
    coordinates: [22.5726, 88.3639],
    timestamp: new Date().toISOString(),
    cloud_cover: 35,
    quality_flag: 'moderate'
  },
  {
    id: '5',
    satellite: 'INSAT-3DR',
    aod_value: 0.38,
    coordinates: [13.0827, 80.2707],
    timestamp: new Date().toISOString(),
    cloud_cover: 20,
    quality_flag: 'good'
  },
  {
    id: '6',
    satellite: 'INSAT-3D',
    aod_value: 0.42,
    coordinates: [26.9124, 75.7873],
    timestamp: new Date().toISOString(),
    cloud_cover: 18,
    quality_flag: 'good'
  },
  {
    id: '7',
    satellite: 'INSAT-3DR',
    aod_value: 0.71,
    coordinates: [28.7041, 77.1025],
    timestamp: new Date().toISOString(),
    cloud_cover: 12,
    quality_flag: 'good'
  },
  {
    id: '8',
    satellite: 'INSAT-3DS',
    aod_value: 0.29,
    coordinates: [15.2993, 74.1240],
    timestamp: new Date().toISOString(),
    cloud_cover: 45,
    quality_flag: 'poor'
  }
];

const mockCPCBStations: CPCBStation[] = [
  {
    id: '1',
    name: 'Anand Vihar',
    location: { lat: 28.6467, lng: 77.3167, city: 'Delhi', state: 'Delhi' },
    pollutants: { pm25: 156, pm10: 234, no2: 45, so2: 12, co: 1.2, o3: 89 },
    aqi: 301,
    status: 'online',
    last_updated: new Date().toISOString()
  },
  {
    id: '2',
    name: 'Bandra Kurla Complex',
    location: { lat: 19.0596, lng: 72.8656, city: 'Mumbai', state: 'Maharashtra' },
    pollutants: { pm25: 89, pm10: 134, no2: 34, so2: 8, co: 0.8, o3: 67 },
    aqi: 156,
    status: 'online',
    last_updated: new Date().toISOString()
  },
  {
    id: '3',
    name: 'BTM Layout',
    location: { lat: 12.9165, lng: 77.6101, city: 'Bangalore', state: 'Karnataka' },
    pollutants: { pm25: 67, pm10: 98, no2: 28, so2: 6, co: 0.6, o3: 54 },
    aqi: 98,
    status: 'online',
    last_updated: new Date().toISOString()
  },
  {
    id: '4',
    name: 'Manali Village',
    location: { lat: 13.1693, lng: 80.2695, city: 'Chennai', state: 'Tamil Nadu' },
    pollutants: { pm25: 78, pm10: 112, no2: 31, so2: 9, co: 0.7, o3: 61 },
    aqi: 123,
    status: 'online',
    last_updated: new Date().toISOString()
  },
  {
    id: '5',
    name: 'Rabindra Bharati University',
    location: { lat: 22.6503, lng: 88.3756, city: 'Kolkata', state: 'West Bengal' },
    pollutants: { pm25: 134, pm10: 189, no2: 42, so2: 14, co: 1.1, o3: 76 },
    aqi: 267,
    status: 'online',
    last_updated: new Date().toISOString()
  }
];

class ApiService {
  private baseUrl = 'https://api.airsight.com';

  async fetchAirQualityData(): Promise<AirQualityData[]> {
    // Simulate API call with realistic variations
    await new Promise(resolve => setTimeout(resolve, 800));
    return mockAirQualityData.map(data => ({
      ...data,
      timestamp: new Date().toISOString(),
      pm25: Math.max(0, data.pm25 + (Math.random() - 0.5) * 20),
      pm10: Math.max(0, data.pm10 + (Math.random() - 0.5) * 30),
      aod: Math.max(0, Math.min(1, data.aod + (Math.random() - 0.5) * 0.1)),
    }));
  }

  async fetchSatelliteData(): Promise<SatelliteData[]> {
    await new Promise(resolve => setTimeout(resolve, 600));
    return mockSatelliteData.map(data => ({
      ...data,
      timestamp: new Date().toISOString(),
      aod_value: Math.max(0, Math.min(1, data.aod_value + (Math.random() - 0.5) * 0.05)),
      cloud_cover: Math.max(0, Math.min(100, data.cloud_cover + (Math.random() - 0.5) * 10)),
    }));
  }

  async fetchCPCBStations(): Promise<CPCBStation[]> {
    await new Promise(resolve => setTimeout(resolve, 500));
    return mockCPCBStations.map(station => ({
      ...station,
      last_updated: new Date().toISOString(),
      pollutants: {
        ...station.pollutants,
        pm25: Math.max(0, station.pollutants.pm25 + (Math.random() - 0.5) * 15),
        pm10: Math.max(0, station.pollutants.pm10 + (Math.random() - 0.5) * 25),
        no2: Math.max(0, station.pollutants.no2 + (Math.random() - 0.5) * 8),
        so2: Math.max(0, station.pollutants.so2 + (Math.random() - 0.5) * 3),
        co: Math.max(0, station.pollutants.co + (Math.random() - 0.5) * 0.3),
        o3: Math.max(0, station.pollutants.o3 + (Math.random() - 0.5) * 12),
      }
    }));
  }

  async predictPM(aod: number, meteorology: any): Promise<{ pm25: number; pm10: number; confidence: number }> {
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    // Enhanced ML prediction simulation with meteorological factors
    const tempFactor = meteorology.temperature > 30 ? 1.1 : 0.9;
    const humidityFactor = meteorology.humidity > 70 ? 1.05 : 0.95;
    const windFactor = meteorology.windSpeed > 10 ? 0.8 : 1.2;
    
    const pm25 = Math.max(0, aod * 180 * tempFactor * humidityFactor * windFactor + Math.random() * 15);
    const pm10 = Math.max(0, pm25 * 1.5 + Math.random() * 25);
    const confidence = Math.min(1, 0.7 + Math.random() * 0.3);
    
    return { pm25, pm10, confidence };
  }

  async getModelPerformance(): Promise<PredictionModel[]> {
    await new Promise(resolve => setTimeout(resolve, 400));
    
    return [
      {
        id: '1',
        name: 'Random Forest v2.1',
        algorithm: 'random_forest',
        accuracy: 0.87,
        mae: 12.4,
        rmse: 18.7,
        last_trained: new Date(Date.now() - 86400000).toISOString(),
        features: ['AOD', 'Temperature', 'Humidity', 'Wind Speed', 'Pressure', 'Solar Radiation']
      },
      {
        id: '2',
        name: 'Neural Network v1.3',
        algorithm: 'neural_network',
        accuracy: 0.82,
        mae: 15.2,
        rmse: 22.1,
        last_trained: new Date(Date.now() - 172800000).toISOString(),
        features: ['AOD', 'Temperature', 'Humidity', 'Wind Speed', 'Pressure', 'NDVI', 'Population Density']
      },
      {
        id: '3',
        name: 'Gradient Boosting v1.0',
        algorithm: 'gradient_boosting',
        accuracy: 0.89,
        mae: 11.8,
        rmse: 17.2,
        last_trained: new Date(Date.now() - 43200000).toISOString(),
        features: ['AOD', 'Temperature', 'Humidity', 'Wind Speed', 'Pressure', 'Boundary Layer Height']
      }
    ];
  }

  async generateSpatialMap(region: string = 'india'): Promise<any> {
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Simulate spatial map generation
    return {
      region,
      resolution: '1km',
      coverage: '3.28M km²',
      dataPoints: 125000,
      generatedAt: new Date().toISOString(),
      downloadUrl: '/api/spatial-maps/india-pm25-latest.tiff'
    };
  }

  async validatePredictions(): Promise<any> {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      totalValidations: 1247,
      accuracy: 0.873,
      mae: 13.2,
      rmse: 19.4,
      r2Score: 0.891,
      validationPeriod: '2024-01-01 to 2024-12-31',
      lastValidated: new Date().toISOString()
    };
  }

  async getAtmosphericData(): Promise<any> {
    await new Promise(resolve => setTimeout(resolve, 700));
    
    return {
      source: 'MERRA-2',
      variables: [
        { name: 'Temperature', unit: '°C', coverage: '100%' },
        { name: 'Humidity', unit: '%', coverage: '100%' },
        { name: 'Wind Speed', unit: 'm/s', coverage: '98%' },
        { name: 'Pressure', unit: 'hPa', coverage: '100%' },
        { name: 'Boundary Layer Height', unit: 'm', coverage: '95%' },
        { name: 'Solar Radiation', unit: 'W/m²', coverage: '92%' }
      ],
      lastUpdated: new Date().toISOString()
    };
  }
}

export const apiService = new ApiService();